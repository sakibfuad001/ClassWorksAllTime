#include<bits/stdc++.h>
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<cstring>

#include <windows.h>
#include <glut.h>
#include "bitmap_image.hpp"

#define pi (2*acos(0.0))
using namespace std;

double cameraHeight;
double cameraAngle;
int drawgrid;
int drawaxes;
double angle;
double angelRotate;
double nearP, farP, visionX, visionY, aspectRatio, recursionLevel, pixelsNo, widthCell, ambient, diffuse, reflection, objectNo;
double centerX, centerY, centerZ, radius, colorR, colorG, colorB, amb_reflect_one, amb_reflect_two, amb_reflect_three, amb_reflect_four;
double pyramidX, pyramidY, pyramidZ, pyramidWidth, pyramidHeight, pyramidColorR, pyramidColorG, pyramidColorB;
double pyramidAmbOne, pyramidAmbTwo, pyramidAmbThree, pyramidAmbFour, pyramidShininess;
double shininess, lightSourceNo, lightSourceX, lightSourceY, lightSourceZ, lightSourceFalloff;
double spotLightNo, spotLightX, spotLightY, spotLightZ, spotLightFalloff;
double lookPointX, lookPointY, lookPointZ, cutOffAngle;
bool textureFlag = false;
string str;

void drawSphere(double x, int y, int z);



class Vector
{
public:
    double x, y, z;

    Vector()
    {

    }
    // constructs a vector with given components
    Vector(double x, double y, double z)
    {
        this->x = x;
        this->y = y;
        this->z = z;
    }

    // keeps the direction same. recalculates the vector to be unit.
    void normalize()
    {
        double r = sqrt(x*x + y*y + z*z);
        x = x / r;
        y = y / r;
        z = z / r;
    }

    // add two vectors
    Vector operator+(const Vector& v)
    {
        Vector v1(x+v.x, y+v.y, z+v.z);
        return v1;
    }

    // subtract one vector from another
    Vector operator-(const Vector& v)
    {
        Vector v1(x-v.x, y-v.y, z-v.z);
        return v1;
    }

    // scale a vector with a given coefficient
    Vector operator* (double m)
    {
        Vector v(x*m, y*m, z*m);
        return v;
    }

    // get the dot product of two vectors
    static double dot(Vector a, Vector b)
    {
        return a.x*b.x + a.y*b.y + a.z*b.z;
    }

    // get the cross product of two vectors
    static Vector cross(Vector a, Vector b)
    {
        Vector v(a.y*b.z - a.z*b.y, b.x*a.z - b.z*a.x, a.x*b.y - a.y*b.x);
        return v;
    }

    // print a vector. only for testing purposes.
    void print ()
    {
        cout << "Vector" << endl;
        cout << x << " " << y << " " << z << endl;
    }
};
double CalcDistance(Vector distPlusVector, Vector posVector);

struct point
{
    double x,y,z;
};
struct point pos,u,r,l;

class Sphere
{
public:
    int id;
    double centerX, centerY, centerZ;
    double radius;
    double colorR, colorG, colorB;
    double amb_reflect_one, amb_reflect_two, amb_reflect_three, amb_reflect_four;
    double shininess;

    Sphere()
    {

    }

    Sphere(int id, double centerX, double centerY, double centerZ, double  radius, double colorR, double colorG, double colorB, double amb_reflect_one, double amb_reflect_two, double amb_reflect_three, double amb_reflect_four, double shininess)
    {
        this->id = id;
        this->centerX = centerX;
        this->centerY = centerY;
        this->centerZ = centerZ;
        this->radius = radius;
        this->colorR = colorR;
        this->colorG = colorG;
        this->colorB = colorB;
        this->amb_reflect_one = amb_reflect_one;
        this->amb_reflect_two = amb_reflect_two;
        this->amb_reflect_three = amb_reflect_three;
        this->amb_reflect_four = amb_reflect_four;
        this->shininess = shininess;
    }
    void print()
    {
        cout<<"Sphere: "<<id<<endl;
        cout<<centerX<<" "<<centerY<<" "<<centerZ<<endl;
        cout<<radius<<endl;
        cout<<colorR<<" "<<colorG<<" "<<colorB<<endl;
        cout<<amb_reflect_one<<" "<<amb_reflect_two<<" "<<amb_reflect_three<<" "<<amb_reflect_four<<endl;
        cout<<shininess<<endl;
    }

    void drawThisSphere()
    {
        glPushMatrix();
        {
            glColor3f(colorR, colorG, colorB);
            glTranslatef(centerX, centerY, centerZ);
            drawSphere(radius, 60, 80);
        }glPopMatrix();
    }
    double intersectionFind(Vector R0, Vector Rd)
    {
        double a,b,c, d, tPlus, tMinus;
        Vector tempR = R0 - Vector(centerX, centerY, centerZ);
        a = Vector::dot(Rd, Rd);
        b = 2*Vector::dot(Rd, tempR);
        c = - pow(radius, 2) + Vector::dot(tempR, tempR) ;

        d = pow(b,2) - 4 * a * c;
        if(d <0)
        {
            return -1;
        }
        d = sqrt(d);

        tPlus = (-b + d)/(2*a);
        tMinus = (-b-d)/(2*a);


        double tTemp;

        Vector distPlusVector = R0 + Rd * tPlus;
        Vector distMinusVector = R0 + Rd * tMinus;
        Vector posVector = Vector(pos.x, pos.y, pos.z);

        double distPlus = CalcDistance(distPlusVector, posVector);
        double distMinus = CalcDistance(distMinusVector, posVector);
        double minDist = min(distPlus, distMinus);

        if(tPlus < 0)
        {
            if(tMinus<0)
            {
                return -1;
            }
            else
            {
                return distMinus<farP ? tMinus:-1;
            }

        }
        else
        {
            if(tMinus<0)
            {
                return distPlus<farP ? tPlus:-1;
            }
            else
            {
                 return minDist<farP? min(tPlus, tMinus): -1;
            }
        }



    }
};

vector<Sphere> SphereVector;

class Pyramid
{
public:
    int id;
    double pyramidX, pyramidY, pyramidZ;
    double pyramidWidth, pyramidHeight;
    double pyramidColorR, pyramidColorG, pyramidColorB;
    double pyramidAmbOne, pyramidAmbTwo, pyramidAmbThree, pyramidAmbFour;
    double pyramidShininess;
    point p1, p2, p3, p4, p5;

    Pyramid()
    {

    }
    Pyramid(int id, double pyramidX, double pyramidY, double pyramidZ, double pyramidWidth, double pyramidHeight, double pyramidColorR, double pyramidColorG, double pyramidColorB, double pyramidAmbOne, double pyramidAmbTwo, double pyramidAmbThree, double pyramidAmbFour, double pyramidShininess)
    {
        this->id = id;
        this->pyramidX = pyramidX;
        this->pyramidY = pyramidY;
        this->pyramidZ = pyramidZ;
        this->pyramidWidth = pyramidWidth;
        this->pyramidHeight = pyramidHeight;
        this->pyramidColorR = pyramidColorR;
        this->pyramidColorG = pyramidColorG;
        this->pyramidColorB = pyramidColorB;
        this->pyramidAmbOne = pyramidAmbOne;
        this->pyramidAmbTwo = pyramidAmbTwo;
        this->pyramidAmbThree = pyramidAmbThree;
        this->pyramidAmbFour = pyramidAmbFour;
        this->pyramidShininess = pyramidShininess;
    }

    void print()
    {
        cout<<"Pyramid: "<<id<<endl;
        cout<<pyramidX<<" "<<pyramidY<<" "<<pyramidZ<<endl;
        cout<<pyramidWidth<<" "<<pyramidHeight<<endl;
        cout<<pyramidColorR<<" "<<pyramidColorG<<" "<<pyramidColorB<<endl;
        cout<<pyramidAmbOne<<" "<<pyramidAmbTwo<<" "<<pyramidAmbThree<<" "<<pyramidAmbFour<<endl;
        cout<<pyramidShininess<<endl;
        cout<<" p1: "<<p1.x<<" "<<endl;
    }

    void drawThisPyramid()
    {
        p1.x = pyramidX;
        p1.y = pyramidY;
        p1.z = pyramidZ;

        p2.x = pyramidX + pyramidWidth;
        p2.y = pyramidY;
        p2.z = pyramidZ;

        p3.x = p2.x;
        p3.y = pyramidY + pyramidWidth;
        p3.z = pyramidZ;

        p4.x = pyramidX;
        p4.y = p3.y;
        p4.z = pyramidZ;

        p5.x = pyramidX + pyramidWidth/2.0;
        p5.y = pyramidY + pyramidWidth/2.0;
        p5.z = pyramidZ + pyramidHeight;



        glColor3f(pyramidColorR, pyramidColorG, pyramidColorB);

        glBegin(GL_QUADS);
        {
            glVertex3f(p1.x, p1.y, p1.z);
            glVertex3f(p2.x, p2.y, p2.z);
            glVertex3f(p3.x, p3.y, p3.z);
            glVertex3f(p4.x, p4.y, p4.z);
        }
        glEnd();

        glBegin(GL_TRIANGLES);
        {
            glVertex3f(p1.x, p1.y, p1.z);
            glVertex3f(p2.x, p2.y, p2.z);
            glVertex3f(p5.x, p5.y, p5.z);

            glVertex3f(p2.x, p2.y, p2.z);
            glVertex3f(p3.x, p3.y, p3.z);
            glVertex3f(p5.x, p5.y, p5.z);

            glVertex3f(p3.x, p3.y, p3.z);
            glVertex3f(p4.x, p4.y, p4.z);
            glVertex3f(p5.x, p5.y, p5.z);

            glVertex3f(p1.x, p1.y, p1.z);
            glVertex3f(p4.x, p4.y, p4.z);
            glVertex3f(p5.x, p5.y, p5.z);
        }
        glEnd();

    }

    double CalcDeterminant(double x1, double y1, double z1, double x2, double y2, double z2, double x3, double y3, double z3)
    {

        double d = x1 * (y2*z3 - z2*y3)- y1 * (x2 * z3 - z2 * x3) + z1 * (x2 * y3 - y2 * x3);
        return d;
    }

    double intersectionFind(Vector R0, Vector Rd)
    {
        double triTOne, triTTwo, triTThree, triTFour;
        Vector a = Vector(p1.x, p1.y, p1.z);
        Vector b = Vector(p2.x, p2.y, p2.z);
        Vector c = Vector(p5.x, p5.y, p5.z);

        Vector first = a - b;
        Vector second = a - c;
        Vector third = Rd;
        Vector finalR = a - R0;

        double d = CalcDeterminant(first.x, first.y, first.z, second.x, second.y, second.z, third.x, third.y, third.z);

        if(d!=0)
        {
            double B = CalcDeterminant(finalR.x, finalR.y, finalR.z, second.x, second.y, second.z, third.x, third.y, third.z);
            B = B/d;

            double G = CalcDeterminant(first.x, first.y, first.z, finalR.x, finalR.y, finalR.z, third.x, third.y, third.z);
            G = G / d;

            triTOne = CalcDeterminant(first.x, first.y, first.z, second.x, second.y, second.z, finalR.x, finalR.y, finalR.z);
            triTOne = triTOne/d;

            if (B <= 0 || G <= 0 || B + G >= 1 || triTOne < 0)
            {
                triTOne = INT_MAX;
            }
        }

        ////////////////////////////
        Vector a1 = Vector(p2.x, p2.y, p2.z);
        Vector b1 = Vector(p3.x, p3.y, p3.z);
        Vector c1 = Vector(p5.x, p5.y, p5.z);

        Vector first1 = a1 - b1;
        Vector second1 = a1 - c1;
        Vector third1 = Rd;
        Vector finalR1 = a1 - R0;

        double d1 = CalcDeterminant(first1.x, first1.y, first1.z, second1.x, second1.y, second1.z, third1.x, third1.y, third1.z);

        if(d!=0)
        {
            double B1 = CalcDeterminant(finalR1.x, finalR1.y, finalR1.z, second1.x, second1.y, second1.z, third1.x, third1.y, third1.z);
            B1 = B1/d1;

            double G1 = CalcDeterminant(first1.x, first1.y, first1.z, finalR1.x, finalR1.y, finalR1.z, third1.x, third1.y, third1.z);
            G1 = G1 / d1;

            triTTwo = CalcDeterminant(first1.x, first1.y, first1.z, second1.x, second1.y, second1.z, finalR1.x, finalR1.y, finalR1.z);
            triTTwo = triTTwo/d1;

            if (B1 <= 0 || G1 <= 0 || B1 + G1 >= 1 || triTTwo < 0)
            {
                triTTwo = INT_MAX;
            }
        }

        /////////////////////////
        Vector a2 = Vector(p3.x, p3.y, p3.z);
        Vector b2 = Vector(p4.x, p4.y, p4.z);
        Vector c2 = Vector(p5.x, p5.y, p5.z);

        Vector first2 = a2 - b2;
        Vector second2 = a2 - c2;
        Vector third2 = Rd;
        Vector finalR2 = a2 - R0;

        double d2 = CalcDeterminant(first2.x, first2.y, first2.z, second2.x, second2.y, second2.z, third2.x, third2.y, third2.z);

        if(d2!=0)
        {
            double B2 = CalcDeterminant(finalR2.x, finalR2.y, finalR2.z, second2.x, second2.y, second2.z, third2.x, third2.y, third2.z);
            B2 = B2/d2;

            double G2 = CalcDeterminant(first2.x, first2.y, first2.z, finalR2.x, finalR2.y, finalR2.z, third2.x, third2.y, third2.z);
            G2 = G2 / d2;

            triTThree = CalcDeterminant(first2.x, first2.y, first2.z, second2.x, second2.y, second2.z, finalR2.x, finalR2.y, finalR2.z);
            triTThree = triTThree/d2;

            if (B2 <= 0 || G2 <= 0 || B2 + G2 >= 1 || triTThree < 0)
            {
                triTThree = INT_MAX;
            }
        }

        Vector a3 = Vector(p4.x, p4.y, p4.z);
        Vector b3 = Vector(p1.x, p1.y, p1.z);
        Vector c3 = Vector(p5.x, p5.y, p5.z);

        Vector first3 = a3 - b3;
        Vector second3 = a3 - c3;
        Vector third3 = Rd;
        Vector finalR3 = a3 - R0;

        double d3 = CalcDeterminant(first3.x, first3.y, first3.z, second3.x, second3.y, second3.z, third3.x, third3.y, third3.z);

        if(d3!=0)
        {
            double B3 = CalcDeterminant(finalR3.x, finalR3.y, finalR3.z, second3.x, second3.y, second3.z, third3.x, third3.y, third3.z);
            B3 = B3/d3;

            double G3 = CalcDeterminant(first3.x, first3.y, first3.z, finalR3.x, finalR3.y, finalR3.z, third3.x, third3.y, third3.z);
            G3 = G3/ d3;

            triTFour = CalcDeterminant(first3.x, first3.y, first3.z, second3.x, second3.y, second3.z, finalR3.x, finalR3.y, finalR3.z);
            triTFour = triTFour/d3;

            if (B3 <= 0 || G3 <= 0 || B3 + G3 >= 1 || triTFour < 0)
            {
                triTFour = INT_MAX;
            }
        }

        double resultT = min(min(triTOne, triTTwo), min(triTThree, triTFour));

        Vector intersectPoint = R0 + Rd * resultT;
        Vector posVector = Vector(pos.x, pos.y, pos.z);

        double distance = CalcDistance(posVector, intersectPoint);

        if(distance>farP)
        {
            resultT = -1;
            ///Do nothing
        }

        double baseT = -1;
        if (Rd.z != 0)
        {
            baseT = (p1.z - R0.z ) / Rd.z ;
            if ( baseT < 0)
            {
                 baseT = -1;
            }

            else
            {
                Vector intersectVector = R0 + Rd * baseT;

                double distance2 = CalcDistance(posVector, intersectVector);

                if (distance2 <= farP )
                {
                    /// DO nothing
                }
                else
                {
                     baseT = -1;
                }

                if (!(p1.x <= intersectVector.x && intersectVector.x <= p2.x && p2.y <= intersectVector.y && intersectVector.y <= p3.y))
                {
                     baseT = -1;
                }

            }
        }

        if(resultT !=-1 && baseT != -1)
        {
            return min(resultT, baseT);
        }
        else if(resultT == -1)
        {
            return baseT;
        }
        else if(baseT == -1)
        {
            return resultT;
        }
        return -1;



    }
};

vector <Pyramid> PyramidVector;

class LightSource
{
public:
    int id;
    double lightSourceX, lightSourceY, lightSourceZ, lightSourceFalloff;
    LightSource()
    {

    }
    LightSource(int id, double lightSourceX, double lightSourceY, double lightSourceZ, double lightSourceFalloff)
    {
        this->id = id;
        this->lightSourceX = lightSourceX;
        this->lightSourceY = lightSourceY;
        this->lightSourceZ = lightSourceZ;
        this->lightSourceFalloff = lightSourceFalloff;
    }

    void print()
    {
        cout<<"LightSource: "<<id<<endl;
        cout<<lightSourceX<<" "<<lightSourceY<<" "<<lightSourceZ<<endl;
        cout<<lightSourceFalloff<<endl;

    }

    void drawThisLight()
    {
        glPushMatrix();
        {
            glTranslatef(lightSourceX, lightSourceY, lightSourceZ);
            glColor3f(1,1,1);
            drawSphere(10, 80,90);
        }
        glPopMatrix();
    }

};

vector <LightSource> LightSourceVector;
class SpotLight
{
public:
    int id;
    double spotLightX, spotLightY, spotLightZ;
    double lookPointX, lookPointY, lookPointZ, spotLightFalloff;
    double cutOffAngle;
    SpotLight()
    {

    }
    SpotLight(int id, double spotLightX, double spotLightY, double spotLightZ, double spotLightFalloff, double lookPointX, double lookPointY, double lookPointZ, double cutOffAngle)
    {
        this->id = id;
        this->spotLightX = spotLightX;
        this->spotLightY = spotLightY;
        this->spotLightZ = spotLightZ;
        this->spotLightFalloff = spotLightFalloff;
        this->lookPointX = lookPointX;
        this->lookPointY = lookPointY;
        this->lookPointZ = lookPointZ;
        this->cutOffAngle = cutOffAngle;
    }

    void print()
    {
        cout<<"SpotLight: "<<id<<endl;
        cout<<spotLightX<<" "<<spotLightY<<" "<<spotLightZ<<endl;
        cout<<spotLightFalloff<<endl;
        cout<<lookPointX<<" "<<lookPointY<<" "<<lookPointZ<<endl;
        cout<<cutOffAngle<<endl;
    }

    void drawThisLight()
    {
        glPushMatrix();
        {
            //glTranslatef(spotLightX, spotLightY, spotLightZ);
            glTranslatef(spotLightX, spotLightY, spotLightZ);
            glColor3f(1,1,1);
            drawSphere(10, 80,90);
        }
        glPopMatrix();
    }
};

vector<SpotLight> SpotLightVector;

void drawAxes()
{
    if(drawaxes==1)
    {
        glColor3f(1.0, 1.0, 1.0);
        glBegin(GL_LINES);
        {
            glVertex3f( 100,0,0);
            glVertex3f(-100,0,0);

            glVertex3f(0,-100,0);
            glVertex3f(0, 100,0);

            glVertex3f(0,0, 100);
            glVertex3f(0,0,-100);
        }
        glEnd();
    }
}


void drawGrid()
{
    int i;
    if(drawgrid==1)
    {
        glColor3f(0.6, 0.6, 0.6);	//grey
        glBegin(GL_LINES);
        {
            for(i=-8; i<=8; i++)
            {

                if(i==0)
                    continue;	//SKIP the MAIN axes

                //lines parallel to Y-axis
                glVertex3f(i*10, -90, 0);
                glVertex3f(i*10,  90, 0);

                //lines parallel to X-axis
                glVertex3f(-90, i*10, 0);
                glVertex3f( 90, i*10, 0);
            }
        }
        glEnd();
    }
}

void drawSquare(double a)
{
    //glColor3f(1.0,0.0,0.0);
    glBegin(GL_QUADS);
    {
        glVertex3f( a, a,2);
        glVertex3f( a,-a,2);
        glVertex3f(-a,-a,2);
        glVertex3f(-a, a,2);
    }
    glEnd();
}


void drawCircle(double radius,int segments)
{
    int i;
    struct point points[100];
    glColor3f(0.7,0.7,0.7);
    //generate points
    for(i=0; i<=segments; i++)
    {
        points[i].x=radius*cos(((double)i/(double)segments)*2*pi);
        points[i].y=radius*sin(((double)i/(double)segments)*2*pi);
    }
    //draw segments using generated points
    for(i=0; i<segments; i++)
    {
        glBegin(GL_LINES);
        {
            glVertex3f(points[i].x,points[i].y,0);
            glVertex3f(points[i+1].x,points[i+1].y,0);
        }
        glEnd();
    }
}

void drawCone(double radius,double height,int segments)
{
    int i;
    double shade;
    struct point points[100];
    //generate points
    for(i=0; i<=segments; i++)
    {
        points[i].x=radius*cos(((double)i/(double)segments)*2*pi);
        points[i].y=radius*sin(((double)i/(double)segments)*2*pi);
    }
    //draw triangles using generated points
    for(i=0; i<segments; i++)
    {
        //create shading effect
        if(i<segments/2)shade=2*(double)i/(double)segments;
        else shade=2*(1.0-(double)i/(double)segments);
        glColor3f(shade,shade,shade);

        glBegin(GL_TRIANGLES);
        {
            glVertex3f(0,0,height);
            glVertex3f(points[i].x,points[i].y,0);
            glVertex3f(points[i+1].x,points[i+1].y,0);
        }
        glEnd();
    }
}


void drawSphere(double radius,int slices,int stacks)
{
    struct point points[100][100];
    int i,j;
    double h,r;
    //generate points
    for(i=0; i<=stacks; i++)
    {
        h=radius*sin(((double)i/(double)stacks)*(pi/2));
        r=radius*cos(((double)i/(double)stacks)*(pi/2));
        for(j=0; j<=slices; j++)
        {
            points[i][j].x=r*cos(((double)j/(double)slices)*2*pi);
            points[i][j].y=r*sin(((double)j/(double)slices)*2*pi);
            points[i][j].z=h;
        }
    }
    //draw quads using generated points
    for(i=0; i<stacks; i++)
    {
        //glColor3f((double)i/(double)stacks,(double)i/(double)stacks,(double)i/(double)stacks);
        for(j=0; j<slices; j++)
        {
            glBegin(GL_QUADS);
            {
                //upper hemisphere
                glVertex3f(points[i][j].x,points[i][j].y,points[i][j].z);
                glVertex3f(points[i][j+1].x,points[i][j+1].y,points[i][j+1].z);
                glVertex3f(points[i+1][j+1].x,points[i+1][j+1].y,points[i+1][j+1].z);
                glVertex3f(points[i+1][j].x,points[i+1][j].y,points[i+1][j].z);
                //lower hemisphere
                glVertex3f(points[i][j].x,points[i][j].y,-points[i][j].z);
                glVertex3f(points[i][j+1].x,points[i][j+1].y,-points[i][j+1].z);
                glVertex3f(points[i+1][j+1].x,points[i+1][j+1].y,-points[i+1][j+1].z);
                glVertex3f(points[i+1][j].x,points[i+1][j].y,-points[i+1][j].z);
            }
            glEnd();
        }
    }
}

void drawSphereGunOne(double radius,int slices,int stacks)
{
    struct point points[100][100];
    int i,j;
    double h,r;
    //generate points
    for(i=0; i<=stacks; i++)
    {
        h=radius*sin(((double)i/(double)stacks)*(pi/2));
        r=radius*cos(((double)i/(double)stacks)*(pi/2));
        for(j=0; j<=slices; j++)
        {
            points[i][j].x=r*cos(((double)j/(double)slices)*2*pi);
            points[i][j].y=r*sin(((double)j/(double)slices)*2*pi);
            points[i][j].z=h;
        }
    }
    //draw quads using generated points
    for(i=0; i<stacks; i++)
    {
        glColor3f((double)i/(double)stacks,(double)i/(double)stacks,(double)i/(double)stacks);
        for(j=0; j<slices; j++)
        {
            glBegin(GL_QUADS);
            {
                //upper hemisphere
                glVertex3f(points[i][j].x,points[i][j].y,points[i][j].z);
                glVertex3f(points[i][j+1].x,points[i][j+1].y,points[i][j+1].z);
                glVertex3f(points[i+1][j+1].x,points[i+1][j+1].y,points[i+1][j+1].z);
                glVertex3f(points[i+1][j].x,points[i+1][j].y,points[i+1][j].z);
                //lower hemisphere
                //glVertex3f(points[i][j].x,points[i][j].y,-points[i][j].z);
                //glVertex3f(points[i][j+1].x,points[i][j+1].y,-points[i][j+1].z);
                //glVertex3f(points[i+1][j+1].x,points[i+1][j+1].y,-points[i+1][j+1].z);
                //glVertex3f(points[i+1][j].x,points[i+1][j].y,-points[i+1][j].z);
            }
            glEnd();
        }
    }
}



void drawSS()
{
    glColor3f(1,0,0);
    drawSquare(20);

    glRotatef(angle,0,0,1);
    glTranslatef(110,0,0);
    glRotatef(2*angle,0,0,1);
    glColor3f(0,1,0);
    drawSquare(15);

    glPushMatrix();
    {
        glRotatef(angle,0,0,1);
        glTranslatef(60,0,0);
        glRotatef(2*angle,0,0,1);
        glColor3f(0,0,1);
        drawSquare(10);
    }
    glPopMatrix();

    glRotatef(3*angle,0,0,1);
    glTranslatef(40,0,0);
    glRotatef(4*angle,0,0,1);
    glColor3f(1,1,0);
    drawSquare(5);
}

void CapturingImage();
void keyboardListener(unsigned char key, int x,int y)
{
    double tempX, tempY, tempZ;
    switch(key)
    {
    case '0':
        CapturingImage();
        break;

    case '1':
        //drawgrid=1-drawgrid;
        tempX = r.x;
        tempY = r.y;
        tempZ = r.z;
        r.x = l.x*sin(angelRotate)+tempX*cos(angelRotate);
        r.y = l.y*sin(angelRotate)+tempY*cos(angelRotate);
        r.z = l.z*sin(angelRotate)+tempZ*cos(angelRotate);
        l.x = l.x*cos(angelRotate)-tempX*sin(angelRotate);
        l.y = l.y*cos(angelRotate)-tempY*sin(angelRotate);
        l.z = l.z*cos(angelRotate)-tempZ*sin(angelRotate);
        break;
    case '2':
        tempX = r.x;
        tempY = r.y;
        tempZ = r.z;
        r.x = tempX*cos(angelRotate)-l.x*sin(angelRotate);
        r.y = tempY*cos(angelRotate)-l.y*sin(angelRotate);
        r.z = tempZ*cos(angelRotate)-l.z*sin(angelRotate);
        l.x = tempX*sin(angelRotate)+l.x*cos(angelRotate);
        l.y = tempY*sin(angelRotate)+l.y*cos(angelRotate);
        l.z = tempZ*sin(angelRotate)+l.z*cos(angelRotate);
        break;
    case '3':
        tempX = u.x;
        tempY = u.y;
        tempZ = u.z;
        u.x = tempX*cos(angelRotate)-l.x*sin(angelRotate);
        u.y = tempY*cos(angelRotate)-l.y*sin(angelRotate);
        u.z = tempZ*cos(angelRotate)-l.z*sin(angelRotate);
        l.x = tempX*sin(angelRotate)+l.x*cos(angelRotate);
        l.y = tempY*sin(angelRotate)+l.y*cos(angelRotate);
        l.z = tempZ*sin(angelRotate)+l.z*cos(angelRotate);

        break;
    case '4':
        tempX = u.x;
        tempY = u.y;
        tempZ = u.z;
        u.x = l.x*sin(angelRotate)+tempX*cos(angelRotate);
        u.y = l.y*sin(angelRotate)+tempY*cos(angelRotate);
        u.z = l.z*sin(angelRotate)+tempZ*cos(angelRotate);
        l.x = l.x*cos(angelRotate)-tempX*sin(angelRotate);
        l.y = l.y*cos(angelRotate)-tempY*sin(angelRotate);
        l.z = l.z*cos(angelRotate)-tempZ*sin(angelRotate);
        break;
    case '5':
        tempX = u.x;
        tempY = u.y;
        tempZ = u.z;
        u.x = r.x*sin(angelRotate)+tempX*cos(angelRotate);
        u.y = r.y*sin(angelRotate)+tempY*cos(angelRotate);
        u.z = r.z*sin(angelRotate)+tempZ*cos(angelRotate);
        r.x = r.x*cos(angelRotate)-tempX*sin(angelRotate);
        r.y = r.y*cos(angelRotate)-tempY*sin(angelRotate);
        r.z = r.z*cos(angelRotate)-tempZ*sin(angelRotate);
        break;
    case '6':
        tempX = u.x;
        tempY = u.y;
        tempZ = u.z;
        u.x = tempX*cos(angelRotate) - r.x*sin(angelRotate);
        u.y = tempY*cos(angelRotate) - r.y*sin(angelRotate);
        u.z = tempZ*cos(angelRotate) - r.z*sin(angelRotate);
        r.x = r.x*cos(angelRotate) + tempX*sin(angelRotate);
        r.y = r.y*cos(angelRotate) + tempY*sin(angelRotate);
        r.z = r.z*cos(angelRotate) + tempZ*sin(angelRotate);
        break;
    case 32:
        textureFlag = !textureFlag;
        break;


    default:
        break;
    }
}


void specialKeyListener(int key, int x,int y)
{
    switch(key)
    {
    case GLUT_KEY_DOWN:
        //down arrow key
        pos.y -= l.y;
        pos.x -=l.x;
        pos.z -=l.z;
        break;
    case GLUT_KEY_UP:		// up arrow key
        pos.y += l.y;
        pos.x +=l.x;
        pos.z +=l.z;
        break;

    case GLUT_KEY_RIGHT:
        pos.y += r.y;
        pos.x +=r.x;
        pos.z +=r.z;
        break;
    case GLUT_KEY_LEFT:
        pos.y -= r.y;
        pos.x -=r.x;
        pos.z -=r.z;
        break;

    case GLUT_KEY_PAGE_UP:
        pos.y += u.y;
        pos.x +=u.x;
        pos.z +=u.z;
        break;
    case GLUT_KEY_PAGE_DOWN:
        pos.y -= u.y;
        pos.x -= u.x;
        pos.z -= u.z;
        break;

    case GLUT_KEY_INSERT:
        break;

    case GLUT_KEY_HOME:
        break;
    case GLUT_KEY_END:
        break;

    default:
        break;
    }
}


void mouseListener(int button, int state, int x, int y) 	//x, y is the x-y of the screen (2D)
{
    switch(button)
    {
    case GLUT_LEFT_BUTTON:
        if(state == GLUT_DOWN) 		// 2 times?? in ONE click? -- solution is checking DOWN or UP
        {
            drawaxes=1-drawaxes;
        }
        break;

    case GLUT_RIGHT_BUTTON:
        //........
        break;

    case GLUT_MIDDLE_BUTTON:
        //........
        break;

    default:
        break;
    }
}


void drawCheckerBoard()
{
    int start = -(widthCell)*farP;
    int finish = (widthCell)*farP;
    bool flag = false;

    for(int i = start; i<finish; i+=widthCell)
    {
        for(int j = start; j<finish; j+=widthCell)
        {
            (flag)? glColor3f(1, 1, 1): glColor3f(0,0,0);
            glBegin(GL_QUADS);
            {
                glVertex3f(i, j, 0);
                glVertex3f(i, j+widthCell, 0);
                glVertex3f(i+widthCell, j+widthCell, 0);
                glVertex3f(i+widthCell, j, 0);
            }glEnd();
            flag = !flag;
        }
        flag = !flag;
    }
}

void drawSphereAll()
{
    for(int i =0; i<SphereVector.size(); i++)
    {
        SphereVector[i].drawThisSphere();
    }
}

void drawPyramidAll()
{
    for(int i =0; i<PyramidVector.size(); i++)
    {
        PyramidVector[i].drawThisPyramid();
    }
}

class color {
public:
    double r, g, b;
    color(double r, double g, double b) {
        this->r = r;
        this->g = g;
        this->b = b;
    }
    color() {
    }
};

double CalcDistance(Vector posVector, Vector interSectPoint)
{
    return sqrt(pow((posVector.x - interSectPoint.x),2) + pow((posVector.y - interSectPoint.y),2) + pow((posVector.z - interSectPoint.z),2));
}


void CapturingImage()
{
    bitmap_image b_img ("texture.bmp");

    color **textureBuffer;
    int height, width;

    height = b_img.height();
    width = b_img.width();
    textureBuffer = new color* [width];
    for (int i = 0; i < width; i++)
    {
        textureBuffer[i] = new color [height];
        for (int j = 0; j < height; j++)
        {
            unsigned char r, g, b;
            b_img.get_pixel(i, j, r, g, b);
            color c(r/255.0, g/255.0, b/255.0);
            textureBuffer[i][j] = c;
        }
    }

    color **pixelColor;
    pixelColor = new color*[(int)pixelsNo];

    for (int i = 0; i < pixelsNo; i++)
    {
        pixelColor[i] = new color[(int)pixelsNo];
        for (int j = 0; j < pixelsNo; j++)
        {
            pixelColor[i][j] = color(0, 0, 0);
        }
    }

    ////////////////////////
    double tempVisionY = (visionY * pi)/180;
    double widthScreen = 2 * nearP * tan(tempVisionY/2);
    double tempVisionX = aspectRatio * tempVisionY;
    double heightScreen = 2 * nearP * tan(tempVisionX/2);

    point midPoint;
    midPoint.x = pos.x + nearP * l.x;
    midPoint.y = pos.y + nearP * l.y;
    midPoint.z = pos.z + nearP * l.z;

    point topLeft;
    cout<<endl<<heightScreen<<endl;
    topLeft.x = midPoint.x + u.x * heightScreen * 0.5;
    topLeft.y = midPoint.y + u.y * heightScreen * 0.5;
    topLeft.z = midPoint.z + u.z * heightScreen * 0.5;
    cout<<topLeft.x <<" "<<topLeft.y <<" "<<topLeft.z<<endl;
    topLeft.x = topLeft.x - r.x * widthScreen * 0.5;
    topLeft.y = topLeft.y - r.y * widthScreen * 0.5;
    topLeft.z = topLeft.z - r.z * widthScreen * 0.5;

    cout<<topLeft.x <<" "<<topLeft.y <<" "<<topLeft.z<<endl;

    topLeft.x = topLeft.x + r.x * (widthScreen/pixelsNo) * 0.5;
    topLeft.y = topLeft.y + r.y * (widthScreen/pixelsNo) * 0.5;
    topLeft.z = topLeft.z + r.z * (widthScreen/pixelsNo) * 0.5;

    Vector bottomLeftVector = Vector(topLeft.x, topLeft.y, topLeft.z);
    bottomLeftVector.print();
    Vector rVector = Vector(r.x, r.y, r.z);
    Vector uVector = Vector(u.x, u.y, u.z);
    Vector lVector = Vector(l.x, l.y, l.z);
    Vector posVector = Vector(pos.x, pos.y, pos.z);
    rVector.normalize();
    uVector.normalize();
    lVector.normalize();

    for(int i = 0; i<pixelsNo; i++)
    {
        //cout<<"hudAI"<<i<<endl;
        for(int j =0 ; j<pixelsNo; j++)
        {

            Vector currentPointVector = bottomLeftVector + rVector * (widthScreen/pixelsNo)*j;
            currentPointVector = currentPointVector - uVector * (heightScreen/pixelsNo) * i;

///           if(i==0  && j==1)
///           {
///               currentPointVector.print();
///           }

            Vector rayVector = currentPointVector - posVector;
            rayVector.normalize();

            double t = -1;

            if(rayVector.z==0)
            {
                ///Do nothing
            }
            else
            {

                t = -currentPointVector.z / rayVector.z;
                Vector interSectPoint = currentPointVector + rayVector * t;


                double distanceValue = CalcDistance(posVector, interSectPoint);

                //cout<<distanceValue<<endl;
                if (i == 400 && j==400 )
                {
                    cout<<" hudai "<<distanceValue<<endl;
                    posVector.print();
                    interSectPoint.print();
                    rayVector.print();
                    currentPointVector.print();
                    //cout<<pixelColor[j][i].r<<" "<<pixelColor[j][i].g<<" "<<pixelColor[j][i].b<<" "<<endl;
                }
                int indexX, indexY;
                if(distanceValue >= farP || t < 0)
                {

                }
                else
                {
                    indexX = (int) (interSectPoint.x/widthCell + farP);
                    indexY = (int) (interSectPoint.y/widthCell + farP);

                    Vector intersectTempVector = interSectPoint;
                    if(textureFlag)
                    {
                        intersectTempVector.x -= indexX * widthCell;
                        intersectTempVector.y -= indexY * widthCell;

                        intersectTempVector.x += widthCell * farP;
                        intersectTempVector.y += widthCell * farP;

                        indexX = intersectTempVector.x * width / widthCell;
                        indexY = intersectTempVector.y * height / widthCell;

                    }
                    //////////////////////////

                    /////////////////////////////
                    double colorValue;
                    if (textureFlag)
                    {
                        ///cout<<textureFlag;
                        pixelColor[j][i].r = textureBuffer[indexX][indexY].r * (255 * ambient);
                        pixelColor[j][i].g = textureBuffer[indexX][indexY].g * (255 * ambient);
                        pixelColor[j][i].b = textureBuffer[indexX][indexY].b * (255 * ambient);
                    }
                    else{
                        colorValue = (255 * ambient )*((indexX + indexY)%2);
                        pixelColor[j][i] = color(colorValue, colorValue, colorValue);

                    }

                }
            }

            double ambientObj;
            double diffuseObj;
            double specObj;
            double reflectionObj;
            double shininessObj;
            color colorObj;
            int flagIntersect = 0;
            int minimumT = 10000000;

            for(int m = 0; m <SphereVector.size(); m++)
            {
                double checkDouble = SphereVector[m].intersectionFind(currentPointVector, rayVector);
                if(checkDouble<0)
                {
                    ///Do nothing
                }
                else
                {
                    flagIntersect = 1;
                    if(checkDouble<minimumT)
                    {
                        minimumT = checkDouble;
                        ambientObj = SphereVector[m].amb_reflect_one;
                        diffuseObj = SphereVector[m].amb_reflect_two;
                        specObj = SphereVector[m].amb_reflect_three;
                        reflectionObj= SphereVector[m].amb_reflect_four;
                        shininessObj = SphereVector[m].shininess;
                        colorObj.r = ambientObj*255*SphereVector[m].colorR;
                        colorObj.g = ambientObj*255*SphereVector[m].colorG;
                        colorObj.b = ambientObj*255*SphereVector[m].colorB;

                    }

                }

            }

            ////////////
            ///Pyramid
            for(int m = 0; m <PyramidVector.size(); m++)
            {
                double checkDouble = PyramidVector[m].intersectionFind(currentPointVector, rayVector);
                if(checkDouble<0)
                {
                    ///Do nothing
                }
                else
                {
                    flagIntersect = 1;
                    if(checkDouble<minimumT)
                    {
                        minimumT = checkDouble;
                        ambientObj = PyramidVector[m].pyramidAmbOne;
                        diffuseObj = PyramidVector[m].pyramidAmbTwo;
                        specObj = PyramidVector[m].pyramidAmbThree;
                        reflectionObj= PyramidVector[m].pyramidAmbFour;
                        shininessObj = PyramidVector[m].pyramidShininess;
                        colorObj.r = ambientObj*255*PyramidVector[m].pyramidColorR;
                        colorObj.g = ambientObj*255*PyramidVector[m].pyramidColorG;
                        colorObj.b = ambientObj*255*PyramidVector[m].pyramidColorB;

                    }

                }

            }

            if (t == -1 && flagIntersect ==1)
            {
                pixelColor[j][i] = colorObj;
            }
            else if( t > 0  && minimumT < t && flagIntersect == 1)
            {
                pixelColor[j][i] = colorObj;
            }

        }
    }


    ////////////////////

    bitmap_image capturing_image((int)pixelsNo, (int)pixelsNo);

    for (int i = 0; i < pixelsNo; i++)
    {
        for (int j = 0; j < pixelsNo; j++)
        {
            capturing_image.set_pixel(i, j, pixelColor[i][j].r, pixelColor[i][j].g, pixelColor[i][j].b);
        }

    }

    capturing_image.save_image("out.bmp");

    for (int i = 0; i < width; i++){
        delete [] textureBuffer[i];
    }
    delete [] textureBuffer;

    for (int i = 0; i < pixelsNo; i++){
        delete [] pixelColor[i];
    }
    delete [] pixelColor;

}

void drawLightSource()
{
    for(int i =0; i<LightSourceVector.size(); i++)
    {
        LightSourceVector[i].drawThisLight();
    }
}

void drawSpotLightSource()
{
    for(int i =0; i<SpotLightVector.size(); i++)
    {
        SpotLightVector[i].drawThisLight();
    }
}


void display()
{

    //clear the display
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearColor(0,0,0,0);	//color black
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    /********************
    / set-up camera here
    ********************/
    //load the correct matrix -- MODEL-VIEW matrix
    glMatrixMode(GL_MODELVIEW);

    //initialize the matrix
    glLoadIdentity();

    //now give three info
    //1. where is the camera (viewer)?
    //2. where is the camera looking?
    //3. Which direction is the camera's UP direction?

    //gluLookAt(100,100,100,	0,0,0,	0,0,1);
    //gluLookAt(200*cos(cameraAngle), 200*sin(cameraAngle), cameraHeight,		0,0,0,		0,0,1);
    //gluLookAt(0,0,200,	0,0,0,	0,1,0);
    gluLookAt(pos.x, pos.y, pos.z,  pos.x + l.x, pos.y + l.y, pos.z + l.z,  u.x, u.y, u.z);


    //again select MODEL-VIEW
    glMatrixMode(GL_MODELVIEW);


    /****************************
    / Add your objects from here
    ****************************/
    //add objects

    //drawAxes();
    //drawGrid();

    //glColor3f(1,0,0);
    //drawSquare(10);

    //drawSS();

    //drawCircle(30,24);

    //drawCone(20,50,24);

    //drawSphere(30,24,20);
    //drawSphereGunOne(30,24,20);

    if(!textureFlag)
    {
        drawCheckerBoard();
    }
    drawSphereAll();
    drawPyramidAll();
    drawLightSource();
    drawSpotLightSource();
    //PyramidVector[0].print();
    //ADD this line in the end --- if you use double buffer (i.e. GL_DOUBLE)
    glutSwapBuffers();
}


void animate()
{
    angle+=0.05;
    //codes for any changes in Models, Camera
    glutPostRedisplay();
}

void init()
{
    //codes for initialization
    drawgrid=0;
    drawaxes=1;
    cameraHeight=150.0;
    cameraAngle=1.0;
    angle=0;

    angelRotate=0.05;

    pos.x=200;
    pos.y=200;
    pos.z=100;

    u.x=0;
    u.y=0;
    u.z=1;

    r.x=-1/sqrt(2);
    r.y=+1/sqrt(2);
    r.z=0;

    l.x=-1/sqrt(2);
    l.y=-1/sqrt(2);
    l.z=0;

    //clear the screen
    glClearColor(0,0,0,0);

    /************************
    / set-up projection here
    ************************/
    //load the PROJECTION matrix
    glMatrixMode(GL_PROJECTION);

    //initialize the matrix
    glLoadIdentity();

    //give PERSPECTIVE parameters
    gluPerspective(visionY,	aspectRatio, nearP,farP);
    //field of view in the Y (vertically)
    //aspect ratio that determines the field of view in the X direction (horizontally)
    //near distance
    //far distance
}

void fileOperation()
{
    ifstream file;
    file.open("description.txt");
    if(!file)
    {
        cout<<"Can't open the file!"<<endl;
        exit(1);
    }
    file>>nearP>>farP>>visionY>>aspectRatio;
    file>>recursionLevel>>pixelsNo>>widthCell>>ambient>>diffuse>>reflection>>objectNo;
    int i =0;
    int cntS=0;
    int cntP=0;
    cout<<"objectNo: "<<objectNo<<endl;
    while(i<objectNo)
    {
        file>>str;
        cout<<str<<endl;
        if(str=="sphere")
        {
            cntS++;
            file>>centerX>>centerY>>centerZ;
            file>>radius;
            file>>colorR>>colorG>>colorB;
            file>>amb_reflect_one>>amb_reflect_two>>amb_reflect_three>>amb_reflect_four;
            file>>shininess;
            Sphere sphere = Sphere(cntS,centerX, centerY, centerZ, radius, colorR, colorG, colorB, amb_reflect_one, amb_reflect_two, amb_reflect_three, amb_reflect_four, shininess);
            sphere.print();
            SphereVector.push_back(sphere);
            //cout<<"S"<<shininess<<endl;
        }
        if(str=="pyramid")
        {
            cntP++;
            file>>pyramidX>>pyramidY>>pyramidZ>>pyramidWidth>>pyramidHeight;
            file>>pyramidColorR>>pyramidColorG>>pyramidColorB;
            file>>pyramidAmbOne>>pyramidAmbTwo>>pyramidAmbThree>>pyramidAmbFour;
            file>>pyramidShininess;
            //cout<<"Ps"<<pyramidShininess<<endl;
            Pyramid pyramid = Pyramid(cntP, pyramidX, pyramidY, pyramidZ, pyramidWidth, pyramidHeight,pyramidColorR, pyramidColorG, pyramidColorB, pyramidAmbOne, pyramidAmbTwo, pyramidAmbThree, pyramidAmbFour, pyramidShininess);
            pyramid.print();
            PyramidVector.push_back(pyramid);
        }

        i++;
    }

    file>>lightSourceNo;

    i=0;
    while(i<lightSourceNo)
    {
        file>>lightSourceX>>lightSourceY>>lightSourceZ>>lightSourceFalloff;
        LightSource lightSource = LightSource(i+1, lightSourceX, lightSourceY, lightSourceZ, lightSourceFalloff);
        lightSource.print();
        LightSourceVector.push_back(lightSource);
        i++;
    }

    file>>spotLightNo;
    i=0;
    while(i<spotLightNo)
    {
        file>>spotLightX>>spotLightY>>spotLightZ>>spotLightFalloff;
        file>>lookPointX>>lookPointY>>lookPointZ;
        file>>cutOffAngle;
        SpotLight spotLight = SpotLight(i+1, spotLightX, spotLightY, spotLightZ, spotLightFalloff, lookPointX, lookPointY, lookPointZ, cutOffAngle);
        spotLight.print();
        SpotLightVector.push_back(spotLight);
        i++;
    }



    file.close();




}

int main(int argc, char **argv)
{
    glutInit(&argc,argv);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(0, 0);
    glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB);	//Depth, Double buffer, RGB color

    glutCreateWindow("My OpenGL Program");

    fileOperation();
    init();

    cout<<lookPointZ;
    glEnable(GL_DEPTH_TEST);	//enable Depth Testing

    glutDisplayFunc(display);	//display callback function
    glutIdleFunc(animate);		//what you want to do in the idle time (when no drawing is occuring)

    glutKeyboardFunc(keyboardListener);
    glutSpecialFunc(specialKeyListener);
    glutMouseFunc(mouseListener);

    glutMainLoop();		//The main loop of OpenGL

    return 0;
}
