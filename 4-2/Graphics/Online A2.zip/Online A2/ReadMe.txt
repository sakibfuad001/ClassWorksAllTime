page up page down keys control spring constant
arrow keys control camera