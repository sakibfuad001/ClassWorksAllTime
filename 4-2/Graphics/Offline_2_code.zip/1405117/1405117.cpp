#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<iostream>

#include <windows.h>
#include <glut.h>

#define pi (2*acos(0.0))



struct point2d
{
    double x, y;
};

struct point2d cp[200];
struct point2d arrow[200];
struct point2d vec_ball[1000000];
struct point2d updatePoint;
struct point2d updatePoint_two;


int cpidx;
int arrowidx;
int flag;
int right_key_flag;
int n;
int flag_g_button;
int flag_u_button;
int flag_a_button;
int flag_index;
int update_click_counter;
int update_index;
int ball_index;
int ball_index_temp;




void drawSquare()
{
    glBegin(GL_QUADS);
    {
        glVertex3d( 3,  3, 0);
        glVertex3d( 3, -3, 0);
        glVertex3d(-3, -3, 0);
        glVertex3d(-3,  3, 0);
    }
    glEnd();
}


void drawCircle(double radius,int segments, double a, double b)
{
    int i;
    struct point2d points[100];
    glColor3f(0,1,1);
    //generate points
    for(i=0;i<=segments;i++)
    {
        points[i].x=radius*cos(((double)i/(double)segments)*2*pi)+a;
        points[i].y=radius*sin(((double)i/(double)segments)*2*pi)+b;
    }
    //draw segments using generated points
    for(i=0;i<segments;i++)
    {
        glBegin(GL_LINES);
        {
			glVertex3f(points[i].x,points[i].y,0);
			glVertex3f(points[i+1].x,points[i+1].y,0);
        }
        glEnd();
    }
}


void keyboardListener(unsigned char key, int x,int y){
	switch(key){

        case '1':
			break;
        case 'g':
            if(flag_g_button==0)
            {
                flag_g_button=1;
            }
            else
            {
                flag_g_button=0;
            }

            break;
        case 'u':
            if(right_key_flag==1)
            {
                flag_u_button=1;
            }
            break;

        case 'a':
            if(right_key_flag==1)
            {
                if(flag_a_button==0){

                    ball_index_temp=0;
                    flag_a_button=1;
                }
                else{

                    ball_index_temp=0;
                    flag_a_button=0;
                }
            }

            break;

		default:
			break;
	}
}

void specialKeyListener(int key, int x,int y){
	switch(key){
		case GLUT_KEY_DOWN:		//down arrow key
			break;
		case GLUT_KEY_UP:		// up arrow key
			break;

		case GLUT_KEY_RIGHT:
			break;
		case GLUT_KEY_LEFT:
			break;

		case GLUT_KEY_PAGE_UP:
			break;
		case GLUT_KEY_PAGE_DOWN:
			break;

		case GLUT_KEY_INSERT:
			break;

		case GLUT_KEY_HOME:
			break;
		case GLUT_KEY_END:
			break;

		default:
			break;
	}
}


void mouseListener(int button, int state, int x, int y){	//x, y is the x-y of the screen (2D)
	switch(button){
		case GLUT_LEFT_BUTTON:
			if(state == GLUT_DOWN && right_key_flag==0){		// 2 times?? in ONE click? -- solution is checking DOWN or UP

                //std::cout << x << " " << y << std::endl;

                if(flag==0){
                    cp[cpidx].x = (double)x;
                    cp[cpidx].y = (double)(600 - y);
                    cpidx++;
                    flag=1;
                    std::cout <<"Point: "<< x << " " << y << std::endl;
                }
                else{
                    arrow[arrowidx].x=(double)x;
                    arrow[arrowidx].y=(double)(600-y);
                    arrowidx++;
                    flag=0;
                    std::cout <<"Arrow: "<< x << " " << y << std::endl;
                }



			}
            else if(state==GLUT_DOWN && right_key_flag==1 && flag_u_button==1){

                if(update_click_counter==0){

                    update_click_counter=1;

                    updatePoint.x=(double)x;
                    updatePoint.y=(double)(600-y);
                }
                else if(update_click_counter==1){

                    update_click_counter=0;
                    flag_u_button=0;

                    updatePoint_two.x=(double)x;
                    updatePoint_two.y=(double)(600-y);

                    if(flag_index==1)
                    {
                        arrow[update_index].x=(double)x;
                        arrow[update_index].y=(double)(600-y);
                    }
                    else if(flag_index==2)
                    {
                        cp[update_index].x=(double)x;
                        cp[update_index].y=(double)(600-y);
                    }
                }
            }
			break;

		case GLUT_RIGHT_BUTTON:
		    if(state==GLUT_DOWN)
            {
                if(cpidx==arrowidx && cpidx>=1)
                {
                    //write the code here
                    right_key_flag=1;
                    std::cout <<"Right key pressed!!!"<< std::endl;
                }
                else
                {
                    //DO Nothing
                    std::cout <<"Right key pressed but odd number of points :(!!!"<< std::endl;
                }
            }
			//........
			break;

		case GLUT_MIDDLE_BUTTON:
			//........
			break;

		default:
			break;
	}
}



void display(){

	//clear the display
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(0,0,0,0);	//color black
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	/********************
	/ set-up camera here
	********************/
	//load the correct matrix -- MODEL-VIEW matrix
	glMatrixMode(GL_MODELVIEW);

	//initialize the matrix
	glLoadIdentity();

	//now give three info
	//1. where is the camera (viewer)?
	//2. where is the camera looking?
	//3. Which direction is the camera's UP direction?

	//gluLookAt(100,100,100,	0,0,0,	0,0,0);
	//gluLookAt(150*cos(cameraAngle), 150*sin(cameraAngle), cameraHeight,		0,0,0,		0,0,1);
	gluLookAt(0,0,0,	0,0,-1,	0,1,0);


	//again select MODEL-VIEW
	glMatrixMode(GL_MODELVIEW);


	/****************************
	/ Add your objects from here
	****************************/
	//add objects
	//glColor3f(1,1,1);
	//drawAxes();
	//drawSquare();
    ball_index=0;
    if(flag_g_button==0){

        int i;
        for (i = 0; i < cpidx; i++)
        {
            glColor3f(0, 1, 0);
            glPushMatrix();
            {
                glTranslatef(cp[i].x, cp[i].y, 0);
                drawSquare();
            }
            glPopMatrix();
        }

        //arrows drawing
        for(i=0; i<arrowidx; i++)
        {
            glPushMatrix();
            {
                //glTranslatef(arrow[i].x, arrow[i].y, 0);
                //drawSquare();


                //has to draw a triangle here

                struct point2d vector_arrow;
                vector_arrow.x = arrow[i].x-cp[i].x;
                vector_arrow.y = arrow[i].y-cp[i].y;

                double mod = sqrt(vector_arrow.x*vector_arrow.x + vector_arrow.y*vector_arrow.y);

                double ax = vector_arrow.x/mod;
                double ay = vector_arrow.y/mod;

//                double ax_perp = -ay;
//                double ay_perp = ax;

                double point_x_mid = cp[i].x+0.8*vector_arrow.x;
                double point_y_mid = cp[i].y+0.8*vector_arrow.y;

                double point_x_1 = point_x_mid-7*ay;
                double point_y_1 = point_y_mid+7*ax;

                double point_x_2 = point_x_mid+7*ay;
                double point_y_2 = point_y_mid-7*ax;

                glColor3f(1,0,0);

//                std::cout<<"point1_x:"<<arrow[i].x<<"y:"<<arrow[i].y<<std::endl;
//                std::cout<<"point2_x:"<<point_x_1<<"y:"<<point_y_1<<std::endl;
//                std::cout<<"point3_x:"<<point_x_2<<"y:"<<point_y_2<<std::endl;

                glPushMatrix();
                glBegin(GL_TRIANGLES);
                {
                    glVertex3f(arrow[i].x,arrow[i].y,0);
                    glVertex3f(point_x_2, point_y_2, 0);
                    glVertex3f(point_x_1,point_y_1,0);
                }
                glEnd();
                glPopMatrix();


                glColor3f(1,1,1);
                glBegin(GL_LINES);
                {
                    glVertex3f(cp[i].x,cp[i].y,0);
                    glVertex3f(arrow[i].x,arrow[i].y,0);
                }
                glEnd();

                glColor3f(1,1,0);
                glTranslatef(arrow[i].x, arrow[i].y, 0);
                drawSquare();


            }
            glPopMatrix();
        }
    }

    //HermitCurves Drawing after right key is pressed

    if(right_key_flag == 1)
    {

        for(int i=0; i<cpidx-1; i++){


            double a_x, b_x, c_x, d_x, a_y, b_y, c_y, d_y;
            a_x = (2*cp[i].x-2*cp[i+1].x+arrow[i].x+arrow[i+1].x);
            b_x = (-3*cp[i].x+3*cp[i+1].x-2*arrow[i].x-arrow[i+1].x);
            c_x = arrow[i].x;
            d_x = cp[i].x;

            a_y = (2*cp[i].y-2*cp[i+1].y+arrow[i].y+arrow[i+1].y);
            b_y = (-3*cp[i].y+3*cp[i+1].y-2*arrow[i].y-arrow[i+1].y);
            c_y = arrow[i].y;
            d_y =  cp[i].y;

            int t=0;

            double q_t_x = pow(t,3) * a_x
                  + pow(t,2) * b_x
                  + t * c_x
                  + d_x;

            double q_t_y = pow(t,3) * a_y
                  + pow(t,2) * b_y
                  + t * c_y
                  + d_y;

//            n=(cp[i+1].x-cp[i].x)*(cp[i+1].x-cp[i].x) + (cp[i+1].y-cp[i].y)*(cp[i+1].y-cp[i].y);
//            n=(int)sqrt(n)+1;

            double dell=1/(double)n;

            double fx = d_x;
            double dell_fx = a_x * pow(dell, 3)+b_x*pow(dell,3)+c_x*dell;
            double dell_fx_sqr = 6*a_x*pow(dell,3)+2*b_x*pow(dell,2);
            double dell_fx_cube = 6*a_x*pow(dell,3);

            double fy = d_y;
            double dell_fy = a_y * pow(dell, 3)+b_y*pow(dell,3)+c_y*dell;
            double dell_fy_sqr = 6*a_y*pow(dell,3)+2*b_y*pow(dell,2);
            double dell_fy_cube = 6*a_y*pow(dell,3);



            for(int j=0; j<=n; j++)
            {
                double temp_fx=fx;
                fx = fx+dell_fx;
                //fx=fx+5;
                dell_fx=dell_fx+dell_fx_sqr;
                dell_fx_sqr=dell_fx_sqr+dell_fx_cube;

                double temp_fy=fy;
                fy = fy+dell_fy;
                //fy=fy+5;
                dell_fy=dell_fy+dell_fy_sqr;
                dell_fy_sqr=dell_fy_sqr+dell_fy_cube;


                //vec_ball.push_back(make_pair(fx, fy));
                //saving the points on the hermit curve
                vec_ball[ball_index].x=fx;
                vec_ball[ball_index].y=fy;
                ball_index++;


                glColor3f(1,1,1);
                //std::cout<<"i: "<<i<<"j: "<<j<<"fx: "<<fx<<" fy: "<<fy<<"delfx:"<<dell<<"dell_fy: "<<dell_fy<<std::endl;
                glBegin(GL_LINES);
                {
                    glVertex3f(temp_fx, temp_fy, 0);
                    glVertex3f(fx, fy, 0);
                }
                glEnd();


            }


        }
        //for the last to first point



        double a_x, b_x, c_x, d_x, a_y, b_y, c_y, d_y;
        a_x = (2*cp[cpidx-1].x-2*cp[0].x+arrow[cpidx-1].x+arrow[0].x);
        b_x = (-3*cp[cpidx-1].x+3*cp[0].x-2*arrow[cpidx-1].x-arrow[0].x);
        c_x = arrow[cpidx-1].x;
        d_x = cp[cpidx-1].x;

        a_y = (2*cp[cpidx-1].y-2*cp[0].y+arrow[cpidx-1].y+arrow[0].y);
        b_y = (-3*cp[cpidx-1].y+3*cp[0].y-2*arrow[cpidx-1].y-arrow[0].y);
        c_y = arrow[cpidx-1].y;
        d_y =  cp[cpidx-1].y;

        int t=0;

        double q_t_x = pow(t,3) * a_x
              + pow(t,2) * b_x
              + t * c_x
              + d_x;

        double q_t_y = pow(t,3) * a_y
              + pow(t,2) * b_y
              + t * c_y
              + d_y;

//            n=(cp[i+1].x-cp[i].x)*(cp[i+1].x-cp[i].x) + (cp[i+1].y-cp[i].y)*(cp[i+1].y-cp[i].y);
//            n=(int)sqrt(n)+1;

        double dell=1/(double)n;

        double fx = d_x;
        double dell_fx = a_x * pow(dell, 3)+b_x*pow(dell,3)+c_x*dell;
        double dell_fx_sqr = 6*a_x*pow(dell,3)+2*b_x*pow(dell,2);
        double dell_fx_cube = 6*a_x*pow(dell,3);

        double fy = d_y;
        double dell_fy = a_y * pow(dell, 3)+b_y*pow(dell,3)+c_y*dell;
        double dell_fy_sqr = 6*a_y*pow(dell,3)+2*b_y*pow(dell,2);
        double dell_fy_cube = 6*a_y*pow(dell,3);



        for(int j=0; j<=n; j++)
        {
            double temp_fx=fx;
            fx = fx+dell_fx;
            //fx=fx+5;
            dell_fx=dell_fx+dell_fx_sqr;
            dell_fx_sqr=dell_fx_sqr+dell_fx_cube;

            double temp_fy=fy;
            fy = fy+dell_fy;
            //fy=fy+5;
            dell_fy=dell_fy+dell_fy_sqr;
            dell_fy_sqr=dell_fy_sqr+dell_fy_cube;

            //saving the points on hermit curve
            vec_ball[ball_index].x=fx;
            vec_ball[ball_index].y=fy;
            ball_index++;

            //drawing the segments
            glColor3f(1,1,1);
            //std::cout<<"i: "<<i<<"j: "<<j<<"fx: "<<fx<<" fy: "<<fy<<"delfx:"<<dell<<"dell_fy: "<<dell_fy<<std::endl;
            glBegin(GL_LINES);
            {
                glVertex3f(temp_fx, temp_fy, 0);
                glVertex3f(fx, fy, 0);
            }
            glEnd();

        }

        //selects the point to be updated
        if(flag_u_button==1 && update_click_counter==1)
        {
            int min_index_cp=-1;
            double min_distance_cp=1000000.0;

            for(int k=0; k<cpidx; k++)
            {
                double temp_distance_cp=(updatePoint.x-cp[k].x)*(updatePoint.x-cp[k].x)+(updatePoint.y-cp[k].y)*(updatePoint.y-cp[k].y);
                temp_distance_cp=sqrt(temp_distance_cp);
                if(temp_distance_cp<=min_distance_cp){

                    min_distance_cp=temp_distance_cp;
                    min_index_cp=k;
                }
            }

            int min_index_arrow=-1;
            double min_distance_arrow=1000000.0;

            for(int k=0; k<arrowidx; k++)
            {
                double temp_distance_arrow=(updatePoint.x-arrow[k].x)*(updatePoint.x-arrow[k].x)+(updatePoint.y-arrow[k].y)*(updatePoint.y-arrow[k].y);
                temp_distance_arrow=sqrt(temp_distance_arrow);
                if(temp_distance_arrow<=min_distance_arrow){

                    min_distance_arrow=temp_distance_arrow;
                    min_index_arrow=k;
                }
            }

            if(min_distance_arrow<min_distance_cp)
            {
                flag_index=1;
                update_index=min_index_arrow;
                double frac=0.4;
                double rad=0;
                for(int k=0; k<=25; k++)
                {
                    drawCircle(rad, 20, arrow[update_index].x, arrow[update_index].y);
                    rad+=frac;
                }
            }
            else
            {
                flag_index=2;
                update_index=min_index_cp;
                double frac=0.4;
                double rad=0;
                for(int k=0; k<=25; k++)
                {
                    drawCircle(rad, 30, cp[update_index].x, cp[update_index].y);
                    rad+=frac;
                }
            }


        }

        //moving the ball
        if(flag_a_button==1)
        {
            double frac=0.3;
            double rad=0;
            for(int k=0; k<=20; k++)
            {
                drawCircle(rad, 30, vec_ball[ball_index_temp].x, vec_ball[ball_index_temp].y);
                rad+=frac;
            }
            if(ball_index_temp>=ball_index)
            {
                ball_index_temp=0;
            }
        }

    }

	//ADD this line in the end --- if you use double buffer (i.e. GL_DOUBLE)
	glutSwapBuffers();
}


void animate(){


	//codes for any changes in Models, Camera
	ball_index_temp=ball_index_temp+1;
	glutPostRedisplay();
}

void init(){
	//codes for initialization

	cpidx = 0;
	arrowidx=0;
	flag=0;
	right_key_flag=0;
	flag_g_button=0;
	flag_u_button=0;
	flag_a_button=0;
	update_click_counter=0;
	update_index=-1;
	flag_index=0;
	ball_index=0;
	ball_index_temp=0;
	n=1000;

	//clear the screen
	glClearColor(0,0,0,0);

	/************************
	/ set-up projection here
	************************/
	//load the PROJECTION matrix
	glMatrixMode(GL_PROJECTION);

	//initialize the matrix
	glLoadIdentity();

	//give PERSPECTIVE parameters
	gluOrtho2D(0, 800, 0, 600);
	//gluPerspective(80,	1,	1,	1000.0);
	//field of view in the Y (vertically)
	//aspect ratio that determines the field of view in the X direction (horizontally)
	//near distance
	//far distance
}

int main(int argc, char **argv){
	glutInit(&argc,argv);
	glutInitWindowSize(800, 600);
	glutInitWindowPosition(0, 0);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB);	//Depth, Double buffer, RGB color

	glutCreateWindow("My  Program");

	init();

	glEnable(GL_DEPTH_TEST);	//enable Depth Testing

	glutDisplayFunc(display);	//display callback function
	glutIdleFunc(animate);		//what you want to do in the idle time (when no drawing is occuring)

	glutKeyboardFunc(keyboardListener);
	glutSpecialFunc(specialKeyListener);
	glutMouseFunc(mouseListener);

	glutMainLoop();		//The main loop of OpenGL

	return 0;
}
