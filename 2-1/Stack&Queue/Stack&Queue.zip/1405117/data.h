#ifndef DS_DATA_H
#define DS_DATA_H

struct Data
{
    int x;
};

#endif
