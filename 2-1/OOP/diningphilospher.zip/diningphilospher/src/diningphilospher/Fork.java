/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diningphilospher;

/**
 *
 * @author user
 */
public class Fork {
    
    public boolean []forks=new boolean[5];
    
    public Fork(){
        //set all to available at start
    }
    
    //write appropriate syncronized occupy / release method
    
}
