/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diningphilospher;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class Main implements Runnable{
    public Philospher []philosphers=new Philospher[5];  
    public void StartSimulation(){
    
               
          Thread []philThreads=new Thread[5];
          
          for(int i=0;i<philThreads.length;i++){
                philThreads[i]=new Thread(philosphers[i]);
                philThreads[i].start();          
          }

          (new Thread(this)).start();
    }    

    @Override
    public void run() {
        
        try {
            //print Status of Philospher
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
 
    
}
