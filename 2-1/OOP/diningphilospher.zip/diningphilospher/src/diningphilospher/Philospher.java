/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diningphilospher;

/**
 *
 * @author user
 */
public class Philospher implements Runnable{
    
    public int left;
    public int right;
    
    public boolean state;
    
    public Philospher(int l,int r){
        ///
    }

    @Override
    public void run() {
        while(true){
            //write your codes for occupiing forks
            
        }
    }
    
    
}
