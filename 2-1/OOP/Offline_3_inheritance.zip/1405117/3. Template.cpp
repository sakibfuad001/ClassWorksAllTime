#include <iostream>
#include <stdio.h>
#include <string.h>
#include <ctime>
#include <stdlib.h>
using namespace std;

template<typename T> class Array
{
    int size;
    T *arr;
public:
    /*
    Implement necessary constructors
    N.B.: no destructor is required
    */
    Array()
    {
        arr=NULL;
        size=0;
    }

    void printArray()
    {
        for(int i=0; i<size; i++)
            cout<<i << ": " << arr[i]<<endl;
        cout<<endl;
    }

    /*
    Implement the following functions
    1) maximum() which calculates the maximum value in Array
    2) minimum() which calculates the minimum value in Array
    3) setArray() which initializes the array with values
    4) reverseArray() which reverses the Array
    5) getElement() which returns the element at specified index
    */
    T maximum(int *n)
    {
        T max_m=arr[0];
        for(int i=0; i<size; i++)
        {
            if(arr[i]>=max_m)
            {
                max_m=arr[i];
                *n=i;
            }
        }
        return max_m;
    }

    T minimum(int *n)
    {
        T min_m=arr[0];
        for(int i=0; i<size; i++)
        {
            if(min_m>=arr[i])
            {
                min_m=arr[i];
                *n=i;
            }
        }
        return min_m;
    }
    void setArray(T *a, int length)
    {
        arr=a;
        size=length;
    }
    void reverseArray()
    {
        T temp;
        for (int i = 0; i < size/2; ++i)
        {
            temp= arr[i];
            arr[i] = arr[size-i-1];
            arr[size-i-1] = temp;

        }
    }
    T getElement(int n)
    {
        return arr[n];
    }
   /* int get_index(T element)
    {
        int i;
        for(i=0; i<size; i++)
        {
            if(element==arr[i])
            {
                break;
            }
        }
        return i;
    }*/

};

/*
Implement the template function getRandom()
*/
template<typename T> T getRandom(Array<T> newArray, int length)
{
    srand(time(0));
    int r=rand()%length;
    return newArray.getElement(r);
}

template<typename T> void doSomething(T *a, int length)
{
    /*
    Implement this template function which can take any type of array and size of the array as inputs
    */
    int n;
    Array<T> newArray;
    newArray.setArray(a, length);

    newArray.printArray();
    cout<<"Random element: "<< getRandom(newArray, length)<<endl;
    cout<<"Maximum is "<<newArray.maximum(&n);
    cout<<" at index: "<<n<<endl;

    cout<<"Minimum is "<<newArray.minimum(&n);
    cout<<" at index: "<<n<<endl<<endl;

    /*
    reverse the newArray and print the reversed array
    */
    cout<<"------------Reversed array------------"<<endl<<endl;
    newArray.reverseArray();
    newArray.printArray();
    cout<<"--------------------------------------"<<endl<<endl;
}

int main()
{
    double d_array[] = {14.1, 23.78, 15.143, 7.124, 1.453};
    doSomething(d_array, 5);

    int i_array[] = {5, 7, 52, 25, 16, 71, 23};
    doSomething(i_array, 7);

    char* str[] = {"Hello", "Employee", "Student", "Moment"};
    doSomething(str, 4);


    return 0;
}
