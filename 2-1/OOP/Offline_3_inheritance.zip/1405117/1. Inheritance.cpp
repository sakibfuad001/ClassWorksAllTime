#include<iostream>
#include<string>
using namespace std;

class Animal
{
    protected:
    string animalName;


public:
   //write the necessary constructors and Speak() function

   Animal()
   {

   }

    Animal(string str)
    {
        animalName=str;
    }

    string GetName()
    {
        return animalName; //returns name of the animal
    }
    virtual string Speak()
    {
        return "Its own language!!!";
    }

};

class Domestic
{
protected:
    bool hasHouse;
public:
     //Write necesary constructors and Eat() function
     Domestic()
     {

     }
     Domestic(bool var)
     {
         hasHouse=var;
     }
     virtual string  Eat()
     {
       return "Its favorite food!!!";
     }

};

class Cat: public Animal,public Domestic
{
public:
    // write the necessary constructors and other necessary functions
    Cat(string str, bool var):Animal(str), Domestic(var){}//constructor

    string  Speak()
    {
        return " mew.....mew...!!!";
    }

    string  Eat()
    {
        return " milk, fish etc.";
    }

};

class Dog:public Animal
{
public:
    // write the necessary constructors and other necessary functions
    Dog(string str):Animal(str){}

    string Speak()
    {
        return " gheu....gheu....!!";
    }

};

void SpeakReport(Animal &rAnimal)
{
    cout <<rAnimal.GetName() << " says " << rAnimal.Speak() << endl;
}

void EatReport(Domestic &dAnimal)
{
    cout<<"eats" << dAnimal.Eat()<<endl;
}

int main()
{
    Animal ob;
    Domestic ob1;
    Cat cCat("Fred",true);
    Dog dDog("Dino");

    Animal *a;
    Domestic *d;
    a=&ob;
    cout<<a->Speak()<<endl;

    d =&ob1;
    cout<<d->Eat()<<endl;

    a= &dDog;
    cout<<a->Speak()<<endl;

    a=&cCat;
    cout<<a->Speak()<<endl;

    d=&cCat;
    cout<<d->Eat()<<endl;

    SpeakReport(dDog);
    SpeakReport(cCat);
    EatReport(cCat);

    return 0;
}
