#include <iostream>
#include <stdio.h>
#include <string>
#include <ctime>
#include <stdlib.h>
using namespace std;

/**************** Do not modify Student class ******************/
class Student
{
    double cgpa;
protected:
    string name;
    double marks;
    int semester;
    void setGPA(double gpa)
    {
        cgpa = gpa;
    }
public:
    int id;
    string getName()
    {
        return name;
    }
    double getGPA()
    {
        return cgpa;
    }
    void print()
    {
        cout<< "Student Name: "<<name<<endl;
        cout<< "ID: "<<id<<endl;
        cout<< "Current Semester: "<<semester<<endl;
        cout<< "Marks: "<<marks<<endl;
    }
    /**
    calculateGrade() calculates the grade of a Student similar to BUET
    and returns the calculated grade
    */
    virtual string calculateGrade()=0;
    friend void upgrade(Student *s, string grade);
};
/***********************************************************************/


void upgrade(Student* s, string grade)
{
    /**
    Make this function friend to Student class
    and invoke this function if a Student passed
    */
    if(s->getGPA()>=2.00)
    {
        cout<<"Student's grade is "<<grade<<endl;
        cout<<"Passed!!!"<<endl;

    }
    else
    {
        cout<<"Student's grade is "<<grade<<endl;
        cout<<"Failed :("<<endl;
    }
}

class UnderGrad:public Student  /// Complete UnderGrad class which inherits Student
{
    /// No extra variable or function can be added
public:

   UnderGrad(string str,int id_no, int semes, double mks)
   {
       name=str;
       id=id_no;
       semester=semes;
       marks=mks;
   }
    string calculateGrade()
    {
        if(marks>=80)
        {
            setGPA(4.0);
            return "A+";
        }
        else if(marks>=75)
        {
            setGPA(3.75);
            return "A";
        }
        else if(marks>=70){
            setGPA(3.50);
            return "A-";
        }
        else if(marks>=65)
        {
            setGPA(3.25);
            return "B+";
        }
        else if(marks>=60)
        {
            setGPA(3.00);
            return "B";
        }
        else if(marks>=55)
        {
            setGPA(2.75);
            return "B-";
        }
        else if(marks>=50)
        {
            setGPA(2.50);
            return "C+";
        }
        else if(marks>=45)
        {
            setGPA(2.25);
            return "C";
        }
        else if(marks>=40)
        {
            setGPA(2.0);
            return "D";
        }
        else
        {
            setGPA(0.00);
            return "F";
        }
    }

};

class Graduate:public Student /// Complete Graduate class which inherits Student
{
    /// No extra variable or function can be added
public:


    Graduate(string str,int id_no, int semes, double mks)
    {
        name = str;
        id=id_no;
        semester=semes;
        marks=mks;
    }
    string calculateGrade()
    {
        if(marks>=80)
        {
            setGPA(4.0);
            return "A+";
        }
        else if(marks>=75)
        {
            setGPA(3.75);
            return "A";
        }
        else if(marks>=70)
        {
            setGPA(3.50);
            return "A-";
        }
        else if(marks>=65)
        {
            setGPA(3.25);
            return "B+";
        }
        else if(marks>=60)
        {
            setGPA(3.00);
            return "B";
        }
        else if(marks>=55)
        {
            setGPA(2.75);
            return "B-";
        }
        else if(marks>=50)
        {
            setGPA(2.50);
            return "C+";
        }
        else if(marks>=45)
        {
            setGPA(2.25);
            return "C";
        }
        else if(marks>=40)
        {
            setGPA(2.0);
            return "D";
        }
        else
        {
            setGPA(0.00);
            return "F";
        }

    }
};

int main()
{
    Student *student[5];
    string name;
    srand(time(0));

    for(int i=0; i<5; i++)
    {
        int ID = rand()%100;
        int semester = rand()%8+1;
        int mark = (double)(rand()%10000)/(double)100.0;
        cout<<"Write Name of the student: "<<i+1<<endl;
        cin>>name;

        if(rand()%2 == 0)
        {
            /// Create student[i] which points to UnderGrad

            student[i]=new UnderGrad(name, ID, semester, mark);
        }
        else
        {
            /// Create student[i] which points to Graduate

            student[i]= new Graduate(name,ID, semester, mark);
        }
    }

    /**
    Print all information of all UnderGrad students
    and after calulating grades, print CGPAs of all UnderGrad students
    */
    cout<<"--Information of UnderGrad students--"<<endl;

    for(int i=0; i<5; i=i+2)
    {
        student[i]->print();
        upgrade(student[i], student[i]->calculateGrade());
        cout<<"CGPA: "<<student[i]->getGPA();
        cout<<endl<<"----------------------------------"<<endl<<endl;
    }

    for(int i=0; i<5; i++)
    {
        delete student[i];
    }


    return 0;
}

