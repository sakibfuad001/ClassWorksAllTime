#include <iostream>
#include <stdio.h>
#include <string.h>

using namespace std;

class Employee
{
        char* name;
        int age;
    public:
        int id;
        int salary;

        /*
        Implement two constructors
        1) take id and salary
        2) take all parameters
        */

        Employee(int a, int b)
        {
            id=a;
            salary=b;
            name=NULL;
        }
        Employee(char *p, int a, int b, int c )
        {
            name=new char[strlen(p)+1];
            strcpy(name, p);
            age=a;
            id=b;
            salary=c;
        }



        // Implement a copy constructor

        Employee(const Employee &ob)
        {
            name=new char[strlen(ob.name)+1];
            strcpy(name, ob.name);
            age=ob.age;
            id=ob.id;
            salary=ob.salary;
        }
        void setInfo(char *p, int a)
        {
            name=new char[strlen(p)+1];
            strcpy(name, p);
            age=a;
        }

        char *get_name()
        {
            return name;
        }

        /*
        Implement + and = operator
        */
        Employee& operator +( Employee &ob)
        {

            salary=salary+ob.salary;
            return *this;
        }


        Employee & operator =(Employee &ob)
         {
            name=new char[strlen(ob.name)+1];
            strcpy(name, ob.name);
            age=ob.age;
            id=ob.id;
            salary=ob.salary;

            return *this;
         }

        void print()
        {
            cout<<"\n----------------------------------------\n";
            cout << "Employee ID: " << id<<endl;
            cout << "Employee Name: " << name<<endl;
            cout << "Employee age: " << age<<endl;
            cout << "Employee salary: " << salary<<endl;
            cout<<"----------------------------------------\n\n";
        }
        friend char* getName(Employee &ob);
};

char* getName(Employee &ob)
{
    return ob.name;
}

void scale()
{

}

int main()
{
    Employee emp1(1,50000);
    Employee emp2("Cris",30,2,20000);
    emp1.setInfo("Robert", 50);

    emp1.print();
    emp1 = (emp1 + emp2);
    emp1.print();
    emp2.print();

    Employee emp3 = emp1;
    emp3.print();

    string name = getName(emp2);
    cout<< "Employee name of "<<emp2.id<< " is: "<< name<< endl;

    name = emp2.get_name();
    cout<< "Employee name of "<<emp2.id<< " is: "<< name<< endl;

    //scale(emp2);
    emp2.print();

    return 0;
}
