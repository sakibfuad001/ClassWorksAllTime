#include <iostream>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

class Student{
    double *GPA;
    double *credit;
public:
    int ID;
    int total_count;
    /*
    Implement a parameterized constructor
    */
    Student(int a, int b)
    {
        ID=a;
        total_count= b;
    }

    void set_value(double *a, double *b)
    {
        GPA=a;
        credit=b;
    }

    double * get_GPA()
    {
        return GPA;
    }
    double *get_credit()
    {
        return credit;
    }

    void show()
    {
        cout<< "GPA and credit of Student "<<ID<<endl;
        cout<<"------------------------------------"<<endl;
        /*
        Write code for printing GPAs and credits
        */
        for(int i=0; i<total_count; i++)
        {
            cout<<GPA[i]<<"  "<<credit[i];
            cout<<endl;
        }
    }

    //Implement "+" operator which returns the total credit

    double operator+(Student &ob)
    {
        double  sum2=0, sum1=0;
        double *p;
        p=this->get_credit();

        for(int i=0; i<this->total_count; i++){
            sum1=sum1+p[i];
        }

        double *q;
        q=ob.get_credit();

        for(int i=0; i<ob.total_count; i++){
            sum2=sum2+q[i];
        }
        return sum1+sum2;
    }

    //Implement "/" operator which returns the sum of all (GPA*credit)
    double operator/(Student &ob)
    {
        double *x=this->get_credit();
        double *y=this->get_GPA();

        double sum=0, total1=0, total2=0;

        for(int i=0; i<this->total_count; i++)
        {
            sum=x[i]*y[i];
            total1=total1+sum;
        }

        double *u=ob.get_credit();
        double *v=ob.get_GPA();

        for(int i=0; i<ob.total_count; i++)
        {
            sum=u[i]*v[i];
            total2=total2+sum;
        }

        return total1+total2;
    }

    /*Implement "<" operator which returns
      true if average GPA is less than that of the object in parameter
      and
      false if otherwise
    */

    bool operator<(Student &ob)
    {
        double *p=this->get_credit();
        double *q=this->get_GPA();

        double sum=0, product, total=0, avg_this;

        for(int i=0; i<this->total_count; i++)
        {
            sum=sum+p[i];
            product=p[i]*q[i];
            total=total+product;
        }
        avg_this=total/sum;
        double *u=ob.get_credit();
        double *v=ob.get_GPA();

        double sum2=0,total2=0, avg_ob;

        for(int i=0; i<ob.total_count; i++)
        {
            sum2=sum2+u[i];
            product=u[i]*v[i];
            total2=total2+product;
        }

        avg_ob=total2/sum2;

        return avg_this<avg_ob?true:false;
    }
};

int main(){
    Student s1(1,2);
    Student s2(2,2);
    Student s3(3,2);

    /*
    a, b both are double-type array
    initial values are as output file
    */
    double *a=new double[s1.total_count];
    double *b=new double[s1.total_count];
    for(int i=0; i<s1.total_count; i++){
        cin>>a[i];//GPA
        cin>>b[i];//credit
    }
    s1.set_value(a, b);
    s1.show();

    /*
    c, d both are double-type array
    initial values are similar as output file
    */
    double *c=new double[s2.total_count];
    double *d=new double[s2.total_count];
    for(int i=0; i<s2.total_count; i++){
        cin>>c[i];//GPA
        cin>>d[i];//credit
    }
    s2.set_value(c,d);
    s2.show();

    /*
    e, f both are double-type array
    initial values are similar as output file
    */
    double *e=new double[s3.total_count];
    double *f=new double[s3.total_count];
    for(int i=0; i<s3.total_count; i++){
        cin>>e[i];//GPA
        cin>>f[i];//credit
    }
    s3.set_value(e,f);
    s3.show();

    cout<< "CGPA of "<< s1.ID << " and "<< s2.ID <<": "<<(s1/s2)/(s1+s2)<<endl;
    cout<< "CGPA of "<< s2.ID << " and "<< s3.ID <<": "<<(s2/s3)/(s2+s3)<<endl;

    if(s1<s2)
        cout<<s1.ID<<" has less average GPA than "<<s2.ID <<endl;
    if(s2<s3)
        cout<<s2.ID<<" has less average GPA than "<<s3.ID <<endl;

    delete []a;
    delete []b;
    delete []c;
    delete []d;
    delete []e;
    delete []f;
}
