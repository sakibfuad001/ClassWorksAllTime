#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>

using namespace std;

class Shape{
    int x, y, z;
    char *type;
public:
    /*
    Implement a default constructor and required parameterized constructors
    */
    Shape(){x=0; y=0; z=0; type=NULL;}
    Shape(int a,const char*p){
        x=a;
        y=0;
        z=0;
        type=new char[strlen(p)+1];
        strcpy(type, p);
    }
    Shape(int a, int b, const char *p)
    {
        x=a;
        y=b;
        z=0;
        type=new char[strlen(p)+1];
        strcpy(type, p);

    }
    Shape(int a, int b, int c, const char *p){
        x=a;
        y=b;
        z=c;
        type=new char[strlen(p)+1];
        strcpy(type, p);
    }
    int get_dim1(){return x;}
    int get_dim2(){return y;}
    int get_dim3(){return z;}
    char* get_type(){return type;}
    ~Shape(){ delete []type;}
};
/*
    Implement three overloaded fuctions to calculate area
    Each function should return the calculated area
*/


double area(int r) //circle
{
    return (3.1416*r*r);
}

double area(int d1, int d2)
{
    return (d1*d2);
}

double area(int d1, int d2, int d3)
{
    return 2*(d1*d2+d2*d3+d3*d1);
}

double area_print(Shape &ob)
{
    if(!strcmp(ob.get_type(), "circle"))
    {
        //cout<<area(ob.get_dim1())<<endl;
        return area(ob.get_dim1());
    }
    if(!strcmp(ob.get_type(), "cube"))
    {
        //cout<< area(ob.get_dim1(),ob.get_dim2(), ob.get_dim3())<<endl;
        return  area(ob.get_dim1(), ob.get_dim2(), ob.get_dim3());
    }

    if(!strcmp(ob.get_type(),"rectangle"));
    {
        //cout<<area(ob.get_dim1(),ob.get_dim2())<<endl;
        return area(ob.get_dim1(),ob.get_dim2());
    }


}


int main(){
    Shape circle(5, "circle");      //radius = 5
    Shape rectangle(4,9, "rectangle"); //dim1 = 4, dim2 = 9
    Shape cube(2,2,2, "cube");    //dim1 = 3, dim2 = 2, dim3 = 7

    /*
    Calculate area for all shapes and print the values of area
    Decide which function is called based on the "type" of the object
    */
    cout<<area_print(circle)<<endl;
    cout<<area_print(rectangle)<<endl;
    cout<<area_print(cube)<<endl;
    //cout<<cube.get_dim3();

    return 0;

}
