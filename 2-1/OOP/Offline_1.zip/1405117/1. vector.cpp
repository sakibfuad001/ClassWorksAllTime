#include<iostream>
#include <cmath>

using namespace std;

class Vector{

    private:
        int i;
        int j;
        int k;

    public:

        Vector(){
            //print constructing with default values
            i=0;
            j=0;
            k=0;
            cout<<"constructing with default values"<<endl;
        }

        Vector(int a,int b,int c){
            //print constructing with a, b, c values
            i=a;
            j=b;
            k=c;
            cout<<"Constructing "<<" i:"<<i<<"  j:"<<j<<"  k:"<<k<<endl;
        }

        int getI(){
            return i;
        }

        int getJ(){
            return j;
        }

        int getK(){
            return k;
        }

        void setI(int x){
            i=x;
        }

        void setJ(int y){
            j=y;
        }

        void setK(int z){
            k=z;
        }

        double getMagnitude(){
            int temp;
            temp=(i*i)+(j*j)+(k*k);
            return pow(temp, 0.5);
        }

        Vector getDirectionVector(){
            Vector temp;
            temp.setI(i/getMagnitude());
            temp.setJ(j/getMagnitude());
            temp.setK(k/getMagnitude());

            return temp;
        }

        ///return a new vector after adding current vector + vect.
        ///no change to this vector object

        Vector addVector(Vector &vect){
            Vector temp;
            temp.setI(i+vect.getI());
            temp.setJ(j+vect.getJ());
            temp.setK(k+vect.getK());
            return temp;
        }


        Vector getNormalVector(){

        }

        ///return cross product of this vector and the passed vector
        ///no change to this vector

        Vector crossProduct(Vector &vect){
            Vector temp;
            temp.setI(j*vect.getK()-vect.getJ()*k);
            temp.setJ(vect.getI()*k-i*vect.getK());
            temp.setK(i*vect.getJ()-vect.getI()*j);
            return temp;
        }

        ///return dot product of this vector and passed vector as a new vector

        int dotProduct(Vector &vect){
            return (i*vect.getI()+j*vect.getJ()+k*vect.getK());
        }

        //multiply is vector component by this value

        Vector scaling(int multValue){
            Vector temp;
            temp.setI(i*multValue);
            temp.setJ(j*multValue);
            temp.setK(k*multValue);
            return temp;
        }

        //print component

        void printVector(){
            cout<<"("<<i<<")"<<"i + "<<"("<<j<<")"<<"j + "<<"("<<k<<")"<<"k"<<endl;
        }



        ~Vector(){
            cout<<"Destructing ("<<i<<","<<j<<","<<k<<")"<<endl;
        }

};


int main(){

    ///you must be able to explain construct and destructing output sequence
    Vector ob1, ob2(2,-1, 3), ob3(5,8,1);

    ob1.printVector();

    ob1.setI(1);
    ob1.setJ(3);
    ob1.setK(-1);

    ob1.printVector();
    ob2.printVector();
    ob3.printVector();

    ob2.addVector(ob3).printVector();

    ob1.getDirectionVector().printVector();

    ob3.scaling(5).printVector();

    ob2.crossProduct(ob3).printVector();
    ob2.dotProduct(ob3);

    cout<<ob2.getMagnitude()<<endl;

    return 0;
}
