#include <iostream>

using namespace std;

/*
Implement necessary functions with constructors and desctructor
*/

/*
Indicate by printing when constructors and destructor are called
*/

class Object{
	char* type;   ///type can be the inheriting class_name
public:
	int objectID; ///set id through a function
	void setID(int a){objectID=a;}
	Object()
	{
	    type="Object";
	    cout<<"Constructing object"<<endl;
	}
	char* getName()
	{
	    return type;
	}
	~Object()
	{
        cout<<"Destructing object"<<endl;
	}
    virtual int getVolume()=0;
};


class Shape:public Object{
protected:
	int height;
	int width;
public:
    Shape(int a, int b)
    {
        height = a;
        width = b;
        cout<<"Constructing shape"<<endl;
    }
    ~Shape()
    {
        cout<<"Destructing shape"<<endl;
    }
};


class Cube:public Shape{
	int thickness;
public:
    Cube(int a, int b, int c):Shape(a, b)
    {
        thickness=c;
        cout<<"Constructing Cube"<<endl;
    }
    int getVolume()
    {
        return height*width*thickness;
    }
    ~Cube()
    {
        cout<<"Destructing Cube"<<endl;
    }
};

int main()
{
	Cube c1(5,2,3);
	Object *obj;

	obj = &c1;

    cout<<c1.getName()<<"\t"<<c1.getVolume()<<endl;
	cout<<obj->getName()<<"\t"<<obj->getVolume()<<endl;

	obj->setID(5);

	cout<<c1.getName()<<"\t"<<c1.getVolume()<<endl;
	cout<<obj->getName()<<"\t"<<obj->getVolume()<<endl;

	return 0;
}
