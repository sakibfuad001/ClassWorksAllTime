/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multithreading;

import java.util.Scanner;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sakib
 */

class Producer implements Runnable
{
    private final Vector  ara;
    private final int size;
    Producer(Vector ara, int size)
    {
        this.ara=ara;
        this.size=size;
    }
    @Override
    public void run() {
        
        for(int i=1; i<60; i++)
        {
            System.out.println("Producer is  producing  item"+ i);
            try {
                produce(i);
            } catch (InterruptedException ex) {
                System.out.println(ex);
            }
           
             
        }
        
    }

    private void produce(int i) throws InterruptedException {
        while(ara.size()==size)
        {
            synchronized(ara)
            {
                System.out.println("Array is full"+ Thread.currentThread()+" is waiting, "+"Element in the array: "+ ara.size());
                ara.wait();
            }
            
        }
        
        synchronized(ara)
        {
            ara.add(i);
            ara.notifyAll();
            
        }
    }
    
}


class Consumer implements Runnable
{
    private final Vector ara1;
    private final int size1;
    Consumer(Vector ara, int size)
    {
        this.ara1=ara;
        this.size1=size;
    }



    @Override
    public void run() {
        while(true)
        {
            try {
                System.out.println(Thread.currentThread()+" is consuming element: "+ consume()+ " ,Element in the array: "+ ara1.size());
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                Logger.getLogger(Consumer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private int  consume() throws InterruptedException {
        while(ara1.isEmpty())
        {
            synchronized(ara1)
            {
                System.out.println("Array is empty "+ Thread.currentThread()+ " waiting for new element tobe produced");
                ara1.wait();
            }
        }
        
        synchronized (ara1)
        {
            ara1.notifyAll();
            return (Integer) ara1.remove(0);
        }
    }
    
}
public class MultiThreading {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Vector ara=new Vector();
        
        int size = 20;
        
        System.out.println("Enter your choice:");
        System.out.println("Press \'a' for single producer and single consumer application");
        System.out.println("Press \'b' for single producer and multiple consumer application");
        System.out.println("Press \'c' for multiple producer and multiple consumer application");
        
        
        Scanner in=new Scanner(System.in);
        char   ch= in.next().charAt(0);
        
        if(ch=='a')
        {
            Thread producerThread= new Thread(new Producer(ara, size), "Producer");
            Thread consumerThread;
            consumerThread = new Thread(new Consumer(ara, size), "Consumer");
        
            producerThread.start();
            consumerThread.start();
            
        }
        else if(ch=='b')
        {
            Thread producerThread= new Thread(new Producer(ara, size), "Producer");
            Thread consumerThread;
            consumerThread = new Thread(new Consumer(ara, size), "Consumer");
            Thread consumerThread2=new Thread(new Consumer(ara, size), "Consumer2");
        
            producerThread.start();
            consumerThread.start();
            consumerThread2.start();
        }
        
        else if(ch=='c')
        {
            Thread producerThread= new Thread(new Producer(ara, size), "Producer");
            Thread producerThread2= new Thread(new Producer(ara, size), "Producer2");
            Thread producerThread3= new Thread(new Producer(ara, size), "Producer3");
            Thread consumerThread;
            consumerThread = new Thread(new Consumer(ara, size), "Consumer");
            Thread consumerThread2=new Thread(new Consumer(ara, size), "Consumer2");
            Thread consumerThread3=new Thread(new Consumer(ara, size), "Consumer3");
        
            producerThread.start();
            producerThread2.start();
            producerThread3.start();
            consumerThread.start();
            consumerThread2.start();
            consumerThread3.start();
            
        }
  
        
    }

   
    
}
