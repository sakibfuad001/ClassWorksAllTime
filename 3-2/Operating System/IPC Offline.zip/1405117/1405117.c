#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <semaphore.h>

#define steps_AB 100
#define steps_BC 5
#define steps_CD 50
#define steps_DD 300

pthread_t tid[1000];
int counter;
pthread_mutex_t lock;
sem_t semLock;
int personNo;
int noArray[1000];
int arrayBc[steps_BC+1];
int arrayBc22[steps_BC+1];
int personCD;


//stores the thread id and persons speed;

struct PersonInfo
{
    int threadId;
    int speed;
};

struct PersonInfo personArray[1000];

//pathway
void* moveVehicleFunc(void *arg)
{
    int k;
    struct PersonInfo *personVar= (struct PersonInfo *) arg;
    int speed=personVar->speed;
    //AB PATH
    int distance=0;
    while(distance<=steps_AB)
    {
        if(distance+speed<=steps_AB)
        {
            printf("Person %d moved along AB from %d to %d\n\n", personVar->threadId, distance, distance+speed);
            distance=distance+speed;
        }
        else
        {
            break;
        }

        sleep(1);
    }

    printf("Person %d moved along AB from %d to %d\n\n", personVar->threadId, distance-speed, steps_AB);


   //BC PATH


    pthread_mutex_lock(&lock);
    arrayBc[distance]=1;
    distance=0;
    while(distance<steps_BC)
    {

        int k=0;
        if(distance+speed<steps_BC)
        {
            int check=distance;
            for(k=1; k<=speed; k++)
            {
                //printf("sakib\n");
                if(arrayBc[k]==0) continue;

                arrayBc[distance]=0;
                arrayBc[distance+k-1]=1;
                printf("Person %d moved along BC from %d to %d\n\n", personVar->threadId, distance, distance+k-1);

                distance+=k-1;
                sleep(1);
                break;
            }
            if(k==(speed+1))
            {
                printf("Person %d moved along BC from %d to %d\n\n", personVar->threadId, check, k-1);
                arrayBc[k-1]=1;
                arrayBc[check]=0;
                distance=k;
                sleep(1);
            }
        }

        else if((distance+speed)>=steps_BC)
        {

            int check=distance;
            for(k=distance+1; k<=steps_BC; k++)
            {
               // printf("fuad");
                if(arrayBc[k]==0) continue;

                arrayBc[distance]=0;
                arrayBc[k-1]=1;
                printf("Person %d moved along BC from %d to %d\n\n", personVar->threadId, distance, k-1);

                distance=k-1;
                sleep(1);
                break;
            }
            if(k>steps_BC)
            {
                distance=steps_BC;
                arrayBc[steps_BC]=0;
                printf("Person %d moved along BC from %d to %d\n\n", personVar->threadId, check, distance);
                sleep(1);
                break;
            }
        }

       /* if(distance<=steps_BC)
            printf("Person %d moved along BC from %d to %d\n\n", personVar->threadId, distance, steps_BC);
        arrayBc[distance]=0;
        distance=steps_BC;
        arrayBc[steps_BC]=1;
        sleep(1);*/

        break;

    }
    //printf("Person %d moved to point C\n\n", personVar->threadId);

    pthread_mutex_unlock(&lock);
    sleep(1);


    //CD PATH
    //pthread_mutex_lock(&lock);
    distance=0;
    if(personCD==1)
    {
        //personCD=0;
        sem_wait(&semLock);

    }
    if(personCD==0)
    {
        personCD=1;
        while(distance+speed<steps_CD)
        {
            printf("Person %d moved along CD from %d to %d\n\n", personVar->threadId, distance, distance+speed);
            distance=distance+speed;
            sleep(1);
        }
        printf("Person %d moved along CD  from %d to %d\n\n", personVar->threadId, distance, steps_CD);
        personCD=0;
        sem_post(&semLock);
        sleep(1);

    }
    //pthread_mutex_unlock(&lock);
    //

    //PATH DD
    distance=0;
    while(distance+speed<steps_DD)
    {
        printf("Person %d moved along DD from %d to %d\n\n", personVar->threadId, distance, distance+speed);
        distance=distance+speed;
        sleep(1);
    }
    printf("Person %d moved along DD  from %d to %d\n\n", personVar->threadId, distance, steps_DD);
    sleep(1);
    //

    //PATH DC
    //pthread_mutex_lock(&lock);
    //printf("sakib");
    distance=steps_CD;
    if(personCD==1)
    {
        personCD=0;
        sem_wait(&semLock);

    }
    if(personCD==0)
    {
        personCD=1;
        while(distance-speed>0)
        {
            printf("Person %d moved along DC from %d to %d\n\n", personVar->threadId, distance, distance-speed);
            distance=distance-speed;
            sleep(1);
        }
        printf("Person %d moved along DC  from %d to %d\n\n", personVar->threadId, distance, 0);
        personCD=0;
        sem_post(&semLock);
        sleep(1);

    }
   // pthread_mutex_unlock(&lock);


    //CB PATH


    pthread_mutex_lock(&lock);

    distance=steps_BC;
    arrayBc22[distance]=1;
    while(distance>0)
    {

        int k=0;
        if(distance-speed>0)
        {
            int check=distance;
            for(k=1; k<=speed; k++)
            {
                //printf("sakib\n");
                if(arrayBc22[distance-1-k]==0) continue;

                arrayBc22[distance]=0;
                arrayBc22[distance-k+1]=1;
                printf("Person %d moved along CB from %d to %d\n\n", personVar->threadId, distance, distance-k+1);

                distance-=(k-1);
                sleep(1);
                break;
            }
            if(k==(speed+1))
            {
                printf("Person %d moved along CB from %d to %d\n\n", personVar->threadId, check, distance-k+1);
                arrayBc22[distance-k+1]=1;
                arrayBc22[check]=0;
                distance=distance-k+1;
                sleep(1);
            }
        }

        else if((distance-speed)<=0)
        {

            int check=distance;
            for(k=distance-1; k>=0; k--)
            {
                // printf("fuad");
                if(arrayBc22[k]==0) continue;

                arrayBc22[distance]=0;
                arrayBc22[k+1]=1;
                printf("Person %d moved along CB from %d to %d\n\n", personVar->threadId, distance, k+1);

                distance=k+1;
                sleep(1);
                break;
            }
            if(k<0)
            {
                distance=0;
                arrayBc22[check]=0;
                arrayBc22[0]=1;
                printf("Person %d moved along CB from %d to %d\n\n", personVar->threadId, check, 0);
                sleep(1);
                arrayBc22[0]=0;
                break;
            }
        }

        /* if(distance<=steps_BC)
             printf("Person %d moved along BC from %d to %d\n\n", personVar->threadId, distance, steps_BC);
         arrayBc[distance]=0;
         distance=steps_BC;
         arrayBc[steps_BC]=1;
         sleep(1);*/

        break;

    }
    //printf("Person %d moved to point C\n\n", personVar->threadId);

    pthread_mutex_unlock(&lock);
    sleep(1);

    //BA PATH
    distance=steps_AB;
    while(distance>=0)
    {
        if(distance-speed>=0)
        {
            printf("Person %d moved along BA from %d to %d\n\n", personVar->threadId, distance, distance-speed);
            distance=distance-speed;
        }
        else
        {
            break;
        }

        sleep(1);
    }

    printf("Person %d moved along BA from %d to %d\n\n", personVar->threadId, distance+speed, 0);
    sleep(1);

    printf("Person %d has completed his walk\n\n", personVar->threadId );
    //pthread_mutex_lock(&lock);
    //pthread_mutex_unlock(&lock);






}

int main(void)
{
    FILE *fs;
    int res;
    char ch, buffer[32];
    int j = 0;
    int i=0;

    sem_init(&semLock, 0,1);
    for(i=0; i<=1000; i++)
    {
        arrayBc[i]=0;
        arrayBc22[i]=0;
    }
    i=0;
    //opens a file to read
    fs = fopen("/home/sakibfuad/CLionProjects/untitled/in.txt", "r");
    if ( fs == NULL )
    {
        fputs("Cannot open source file\n", stderr);
        exit(EXIT_FAILURE);
    }

    while(1){
        // Reads the character where the seeker is currently
        ch = fgetc(fs);
        if(ch == EOF){
            break;
        }
        else if(ch == '\n'|| ch=='\r' || ch=='\t' || ch==' ' || ch=='\v' || ch=='\f'){
            noArray[j] = atoi(buffer);
            j++;
            // Clearing the buffer, this function takes two
            bzero(buffer, 32);
            // clearing the counter which counts the number
            i = 0;
            continue;
        }
        else{
            buffer[i] = ch;
            i++;
        }
    }

    // printing out all the elements that are stored in the
    // array of integers
   /* for(i = 0; i < j-1; i++){
        printf("Number [%d]: %d\n", i, noArray[i]);
    }*/

    personNo=noArray[0];
    //creates thread for every person
    for(i=1; i<=personNo; i++)
    {
        personArray[i].threadId=i;
        personArray[i].speed=noArray[i];
        //printf("i: %d ch:%c\n",i,  ch);
        res = pthread_create(&(tid[i]), NULL, &moveVehicleFunc, (void *) &personArray[i]);
        if(res!=0)
        {
            printf("\ncan't create thread :[%s]", strerror(res));
        }

        //stores persons speed and thread id in the arrayStructure


    }

    for(i=1; i<=personNo ;i++)
    {
        //printf("%d %d\n", personArray[i].threadId, personArray[i].speed);
        pthread_join(tid[i], NULL);

    }

    pthread_mutex_destroy(&lock);
    fclose(fs);
    exit(EXIT_SUCCESS);
}