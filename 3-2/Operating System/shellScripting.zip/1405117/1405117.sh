#!/bin/bash

cnt=0
treeViewFunc()
{
	cd "$1"
	
	#echo "$cnt"
	for i in *
	do
		if [ -d "$i" ]; then
			for (( j=0; j<$cnt; j++ ))
			do
				echo -n "|  "
			done
			echo "|--$i"
			cnt=`expr $cnt+1`
			treeViewFunc "$i"
		else
			
			for (( j=0; j<$cnt; j++ ))
			do
				echo -n "|  "
			done
			echo  "|--$i"	
		fi
	done
	cd ../
	cnt=`expr $cnt-1`
}

#treeViewFunc "/home/sakibfuad/blog/database"
treeViewFunc 
