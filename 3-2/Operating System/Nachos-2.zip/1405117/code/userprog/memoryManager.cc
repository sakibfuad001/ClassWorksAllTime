#include "memoryManager.h"

MemoryManager::MemoryManager(int numPages)
{
	bitmap = new BitMap(numPages);
	lock = new Lock("lock_one");
}

int MemoryManager::AllocPage()
{
	int freeLocationIndex;
	lock->Acquire();
	freeLocationIndex=bitmap->Find();
	lock->Release();
	return freeLocationIndex;
}

void MemoryManager::FreePage(int pageNum)
{
	lock->Acquire();
	bitmap->Clear(pageNum);
	lock->Release();
}

bool MemoryManager::PageIsAllocated(int pageNum)
{
	bool freeOrnot;
	lock->Acquire();
	freeOrnot = bitmap->Test(pageNum);
	lock->Release();
	return freeOrnot;
}