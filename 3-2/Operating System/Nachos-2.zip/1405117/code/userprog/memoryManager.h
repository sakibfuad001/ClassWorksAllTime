#ifndef MEMORYMANAGER_H
#define MEMORYMANAGER_H
#include "bitmap.h"
#include "synch.h"

class MemoryManager
{
public:
	MemoryManager(int numPages);
	int AllocPage();
	void FreePage(int pageNum);
	bool PageIsAllocated(int pageNum);

private:
	BitMap *bitmap;
	Lock *lock;
};

#endif