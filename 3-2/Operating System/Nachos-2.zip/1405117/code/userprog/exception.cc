// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"
#include "memoryManager.h"
#include "table.h"
#include "machine.h"
#include "synch.h"
#include "addrspace.h"

extern Lock* lockExec;
extern Lock* lockExit;
extern MemoryManager *managerMemory;
extern Table *table;



//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//----------------------------------------------------------------------
void Fork(void* pointr){

    AddrSpace* addrspace = (AddrSpace*) pointr;
    addrspace->InitRegisters();      // set the initial register values
    addrspace->RestoreState();       // load page table register

    machine->Run();         // jump to the user progam
    ASSERT(false);


}
void PcRegisterInc()
{
    int index=machine->ReadRegister(PCReg);
    machine->WriteRegister(PrevPCReg, index);
    index=machine->ReadRegister(NextPCReg);
    machine->WriteRegister(PCReg, index);
    index +=4;
    machine->WriteRegister(NextPCReg, index);
}
void
ExceptionHandler(ExceptionType which)
{
    int type = machine->ReadRegister(2);

    //printf("type: %d which: %d\n",type, which);

    if ((which == SyscallException) && (type == SC_Halt)) {
	DEBUG('a', "Shutdown, initiated by user program.\n");
   	interrupt->Halt();
    } 
    else if((which == SyscallException) && (type == SC_Exit)){
        //printf("exitFirst\n");
    	lockExit->Acquire();
    	printf("Exit code %d\n", machine->ReadRegister(4) );
    	unsigned int k=0;
    	while(k<machine->pageTableSize)
    	{
            //printf("freepageExit %d\n",k );
    		managerMemory->FreePage(machine->pageTable[k].physicalPage);
            k++;
    	}
        if(table->RunningProcess()!=0)
        {
            table->Release(currentThread->pid);
        }
    	
    	lockExit->Release();
    	if(table->RunningProcess()==0)
    	{
    		interrupt->Halt();
    	}
    	//printf("ExitBye\n");
    	currentThread->Finish();
    	
    }
    else if ((which == SyscallException)&&(type==SC_Exec)/* condition */)
    {
    	/* code */
    	lockExec->Acquire();
        //printf("ExecStart\n");
    	int addressVirtual=machine->ReadRegister(4);
    	char nameFile[200];
    	int temporary;
    	machine->ReadMem(addressVirtual,1, &temporary);
    	int i;
        //printf("ExecStartloop\n");
    	for(i=0; *(char*) &temporary !='\0' ; i++)
    	{
            //printf("ExecLoop %d\n",i );
    		nameFile[i]=(char) temporary;
    		addressVirtual++;
    		machine->ReadMem(addressVirtual, 1, &temporary);
    	}
    	nameFile[i] = '\0';

    	AddrSpace *addrspace;
    	OpenFile *executableFile = fileSystem->Open(nameFile);

        if (executableFile == NULL) 
        {
            //printf("Unable to open file %s\n", nameFile);
            return;
        }
        //printf("ExecExecutable1\n");
        Thread *thread = new Thread("threadOne");
       // printf("ExecExecutable2\n");
        addrspace = new AddrSpace(executableFile);
       // printf("ExecExecutable3\n");
        thread->space = addrspace;
        //sprintf("ExecExecutable4\n");
        thread->pid = table->Alloc((void*) thread);
        //printf("ExecExecutable5\n");
        lockExec->Release();

    	//likhte hbe bakita;
        //printf("ExecForkBefore\n");
        thread->Fork(Fork, (void*) thread->space);
        //printf("ExecForkAfter\n");
        machine->WriteRegister(2, thread->pid);
        delete executableFile;
        //printf("ExecTataB\n");
        PcRegisterInc();
        //printf("ExecTataAfter\n");

    }
    else {
	printf("Unexpected user mode exception %d %d\n", which, type);
	ASSERT(false);
    }
}
