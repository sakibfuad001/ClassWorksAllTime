#ifndef TABLE_H
#define TABLE_H
#include "thread.h"

class Table
{
public:
	Table(int size);
	int Alloc(void *object);
	void *Get(int index);
	void Release(int index);
	int RunningProcess();
	int find(void* object);
private:
	void** table;
	int araSize;
	int runningProcess;
};
#endif