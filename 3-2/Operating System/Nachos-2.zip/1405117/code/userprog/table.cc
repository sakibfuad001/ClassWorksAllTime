#include "table.h"

Table::Table(int size)
{
	table = new void*[size];
	araSize = size;
	runningProcess=0;
	int i=0;
	while(i<size)
	{
		table[i]='\0';
		i++;
	}


}

int Table::Alloc(void* object)
{
	int i=0;
	while(i<araSize)
	{
		if(table[i]=='\0')
		{
			runningProcess++;
			table[i]=object;
			return i;

		}
		i++;
	}
	return -1;
}

void* Table::Get(int index)
{
	return table[index];
}

void Table::Release(int index)
{
	runningProcess--;
	table[index]='\0';
}

int Table::find(void* object)
{
	int i=0;
	while(i<araSize)
	{
		if(table[i]==object)
		{
			return i;
		}
		i++;
	}
	return -1;
}

int Table::RunningProcess()
{
	return runningProcess;
}