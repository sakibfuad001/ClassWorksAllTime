#include "syscall.h"

int
main()
{
    int  res=Exec("test/exit");
    Exit(res);
    /* not reached */
}
