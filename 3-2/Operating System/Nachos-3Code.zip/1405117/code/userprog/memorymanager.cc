#include "memorymanager.h"

MemoryManager::MemoryManager(int numPages)
{
	bitMap = new BitMap(numPages);
	lock = new Lock("lock of memory manager");
	processMap = new int[numPages];
	entries = NULL; 
}

MemoryManager::~MemoryManager()
{
	delete bitMap;
	delete lock;
	delete processMap;
	delete entries;
}

int
MemoryManager::AllocPage()
{
	lock->Acquire();
	int ret = bitMap->Find();
	lock->Release();
	return ret;
}

int
MemoryManager:: Alloc(int processNo, TranslationEntry &entry) //new
{
	lock->Acquire();
	int ret = bitMap->Find();
	if(ret>=0)
	{
		processMap[ret]=processNo;
		entries[ret] = entry;
	}
	lock->Release();
	return ret;
}


int
MemoryManager::AllocByForce()
{
	return 0;
}
void
MemoryManager::FreePage(int physPageNum)
{
	lock->Acquire();
	bitMap->Clear(physPageNum);
	lock->Release();
}

bool
MemoryManager::PageIsAllocated(int physPageNum)
{
	lock->Acquire();
	bool ret = bitMap->Test(physPageNum);
	lock->Release();
	return ret;
}

bool
MemoryManager::IsAnyPageFree()
{
	lock->Acquire();
	bool ret;
	if(bitMap->NumClear() == 0)
		ret = false;
	else
		ret = true;
	lock->Release();
	return ret;
}

int
MemoryManager::NumFreePages()
{
	lock->Acquire();
	int ret = bitMap->NumClear();
	lock->Release();
	return ret;
}