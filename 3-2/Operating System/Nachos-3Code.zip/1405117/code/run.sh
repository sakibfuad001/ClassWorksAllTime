cd test
make
cd ../userprog/
make 
./nachos -x ../test/$1