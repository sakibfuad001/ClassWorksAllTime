#! /usr/bin/bash

make
cd threads/
./nachos
