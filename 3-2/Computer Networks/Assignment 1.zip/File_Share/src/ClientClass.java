/**
 * Created by sakib on 30-Sep-17.
 */
import javax.xml.crypto.Data;
import java.io.*;
import java.net.*;
import java.util.*;

public class ClientClass implements Runnable {
    private static Socket socket = null;

    public static int portNumber = 2222;
    public static String host = "localhost";


    public BufferedReader bufferedReader = null;

    public String fileReceiver = null;
    public String fileSender = null;

    private static boolean closed = false;

    public static DataInputStream dataInputStream=null;
    public static DataOutputStream dataOutputStream=null;




    public static void main(String args[]) throws IOException {

        System.out.println("Enter your student id:");
        Scanner scanner=new Scanner(System.in);
        String studentId=scanner.nextLine();
        System.out.println(studentId);

        socket=new Socket(host,portNumber);
        System.out.println("connection established");
         dataInputStream=new DataInputStream(socket.getInputStream());
         dataOutputStream=new DataOutputStream(socket.getOutputStream());

        dataOutputStream.writeUTF(studentId);//sending roll no to the server


        String serverMsg=dataInputStream.readUTF();

        if(serverMsg.equals("NEW"))
        {
            new Thread(new ClientClass()).start();
        }

        else
        {
            System.out.println("Already connected!!!");
        }


    }

    public static void fileReceiveFunc() throws IOException {
        FileOutputStream fos = null;
        BufferedOutputStream bos = null;
        int bytesRead;
        int current = 0;
        try {

            byte[] mybytearray = new byte[8192];

            Scanner scanner = new Scanner(System.in);
            String FILE_TO_RECEIVED=dataInputStream.readUTF();

            InputStream is = socket.getInputStream();
            fos = new FileOutputStream(FILE_TO_RECEIVED);
            bos = new BufferedOutputStream(fos);
            bytesRead = is.read(mybytearray, 0, mybytearray.length);
            current = bytesRead;
            System.out.println(mybytearray.length);


            do {
                bytesRead =
                        is.read(mybytearray, current, (mybytearray.length - current));
                if (bytesRead >= 0) current += bytesRead;
            } while (bytesRead > -1);

            //System.out.println("bye");
            bos.write(mybytearray, 0, current);
            bos.flush();
            //System.out.println("h");
            // System.out.println("File "+ FILE_TO_RECEIVED +" downloaded ("+ current + "bytes read");

        } catch (IOException e) {
            System.out.println(e);
        } finally {
            if (fos != null) fos.close();
            if (bos != null) bos.close();
        }
    }

    public static void fileSendFunc() throws IOException {
        FileInputStream fis = null;
        BufferedInputStream bis = null;
        OutputStream os = null;
        try {


            System.out.println("Sending the file.....");

            System.out.println("Enter the file path:");

            //send file
            Scanner scanner = new Scanner(System.in);

            String FILE_TO_SEND = scanner.nextLine();
            System.out.println(FILE_TO_SEND);

            File myFile = new File(FILE_TO_SEND);
            dataOutputStream.writeUTF(myFile.getName());

            System.out.println(myFile.length());

            //
            byte[] mybytearray = new byte[(int) myFile.length()];
            fis = new FileInputStream(myFile);
            bis = new BufferedInputStream(fis);
            bis.read(mybytearray, 0, mybytearray.length);
            os = socket.getOutputStream();
            //System.out.println("Sending "+ FILE_TO_SEND+" ("+ mybytearray.length+ " bytes)");
            os.write(mybytearray, 0, mybytearray.length);
            //os.flush();
            System.out.println("Done... ");


        } catch (IOException e) {
            System.out.println(e);
        }
       /* finally {
            if(bis!=null) bis.close();
            if(os!=null) os.close();
            if(socket!=null) socket.close();
        }*/


    }

    public void run() {

        int bytesRead;
        int current = 0;

        //BufferedReader bufferedReader = null;
       // PrintWriter printWriter = null;
        String str = null;


        while (true) {
            try {

                socket = new Socket(host, portNumber);
                //System.out.println("New client socket accepted!!!");
               // bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                //printWriter = new PrintWriter(socket.getOutputStream(), true);
                System.out.println("Enter your choice: R for Receiver / S for Sender");
                Scanner scanner = new Scanner(System.in);
                str = scanner.nextLine();

                //printWriter.println(str);

                if (str.equals("R")) {
                    System.out.println("hi");
                    dataOutputStream.writeUTF("R");
                    System.out.println("Client part Receiver");
                    fileReceiveFunc();
                }


                else if (str.equals("S")) {

                    dataOutputStream.writeUTF("S");
                    System.out.println("Client part Sender");
                    fileSendFunc();



                 }


             } catch(IOException e)
            {
                 System.out.println(e);

            }

         }



    }
}
