import java.io.*;
import java.net.Socket;
import java.util.Scanner;

/**
 * Created by sakib on 26-Sep-17.
 */
class ClientThread extends Thread  {
    //FILE OPERATION

    public static FileInfo [] fileInfoArrray;

    public DataOutputStream dataOutputStream=null;
    public DataInputStream dataInputStream=null;

    public FileInputStream fis=null;
    public BufferedInputStream bis=null;
    public OutputStream os=null;
    //
    //public DataInputStream dataInputStream=null;
  //  public PrintStream printStream=null;
    public Socket socket=null;
    public ClientThread[] clinetThreads;
    public int totalClients;
    public final static String FILE_TO_SEND="c:\\temp\\image.jpg";;

    public ClientThread(Socket socket, ClientThread[] clinetThreads, DataInputStream dataInputStream, DataOutputStream dataOutputStream)
    {
        this.socket=socket;
        this.clinetThreads=clinetThreads;
        this.totalClients=clinetThreads.length;
        this.dataInputStream=dataInputStream;
        this.dataOutputStream=dataOutputStream;

    }

    public void run()
    {

        int totalClients=this.totalClients;
        ClientThread[] clientThreads=this.clinetThreads;

            try {


                //send file


           // DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
           //PrintStream printStream=new PrintStream(socket.getOutputStream());
           // printStream.println("Enter your name");
           // String name=dataInputStream.readLine().trim();
           // printStream.println();

            for(int i=0; i!=totalClients; i++)
            {
                if(clientThreads[i]!=null && clientThreads[i]!=this)
                {
                    //clientThreads[i].dataInputStream.
                    String decision="To send file press S OR to  receive file press R ";
                    dataOutputStream.writeUTF(decision);

                    String sederReceiver=dataInputStream.readUTF();


                    if(sederReceiver.equals("S"))//server will receive
                    {
                        try{
                            System.out.println("Server Part Receiver");
                            fileReceiveFunc();
                        } catch (IOException e)
                        {
                            System.out.println(e);
                        }
                    }

                    else if(sederReceiver.equals("R"))//server will send the file
                    {
                        System.out.println("Server Part Sender");
                        fileSendFunc();
                    }

                }
            }

            while(true)
            {
               // String line=dataInputStream.readLine();

                for(int i=0; i<totalClients; i++)
                {
                    if(clientThreads[i]!=null)
                    {

                        //clientThreads[i].printStream.println(name);
                    }
                }

                for(int i = 0; i!=totalClients; i++) {
                    if (clientThreads[i] != null && clientThreads[i] != this) {
                       // clientThreads[i].printStream.println("NEw user");
                    }
                }

                //printStream.println("bye "+name);

                for(int i = 0; i!=totalClients; i++) {
                    if (clientThreads[i] == this) {
                        clientThreads[i]=null;
                    }
                }

            }




        }catch (IOException e)
        {
            System.out.println(e);
        }

    }

    public  void   fileReceiveFunc() throws IOException
    {
        FileOutputStream fos=null;
        BufferedOutputStream bos=null;
        int bytesRead;
        int current=0;
        try{

            System.out.println("Server Receiving");
            byte [] mybytearray = new byte[8192];

            String  FILE_TO_RECEIVED=dataInputStream.readUTF();
            System.out.println(FILE_TO_RECEIVED);

            InputStream is=socket.getInputStream();
            fos= new FileOutputStream(FILE_TO_RECEIVED);
            bos= new BufferedOutputStream(fos);
            bytesRead = is.read(mybytearray,0,mybytearray.length);
            current=bytesRead;
            System.out.println(mybytearray.length);


            do {
                bytesRead =
                        is.read(mybytearray, current, (mybytearray.length-current));
                if(bytesRead >= 0) current += bytesRead;
            } while(bytesRead > -1);

            //System.out.println("bye");
            bos.write(mybytearray, 0, current);
            bos.flush();
            //System.out.println("h");
            // System.out.println("File "+ FILE_TO_RECEIVED +" downloaded ("+ current + "bytes read");

        }catch (IOException e)
        {
            System.out.println(e);
        }
        finally {
            if(fos!=null) fos.close();
            if(bos!=null) bos.close();
        }
    }

    public void  fileSendFunc() throws IOException
    {
        FileInputStream fis=null;
        BufferedInputStream bis=null;
        OutputStream os=null;
        try{


            System.out.println("Accepted connection : "+ socket);

            //send file
            Scanner scanner=new Scanner(System.in);

            String FILE_TO_SEND=scanner.nextLine();

            File myFile=new File(FILE_TO_SEND);
//                    //send_file_size
//                    os=sock.getOutputStream();
//                    os.write((int)myFile.length());
//                    os.flush();
            System.out.println(myFile.length());

            //
            byte [] mybytearray =new byte[(int)myFile.length()];
            fis=new FileInputStream(myFile);
            bis=new BufferedInputStream(fis);
            bis.read(mybytearray,0,mybytearray.length);
            os=socket.getOutputStream();
            //System.out.println("Sending "+ FILE_TO_SEND+" ("+ mybytearray.length+ " bytes)");
            os.write(mybytearray, 0,mybytearray.length);
            //os.flush();
            System.out.println("Done. ");




        } catch (IOException e)
        {
            System.out.println(e);
        }
        finally {
            if(bis!=null) bis.close();
            if(os!=null) os.close();
            if(socket!=null) socket.close();
        }
    }









}
