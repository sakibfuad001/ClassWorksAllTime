/**
 * Created by sakib on 01-Oct-17.
 */
public class FileInfo {
    public String fileName=null;
    public int receiverROll;
    public int senderRoll;

    public FileInfo(String fileName, int receiverROll, int senderRoll) {
        this.fileName = fileName;
        this.receiverROll = receiverROll;
        this.senderRoll = senderRoll;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public int getReceiverROll() {
        return receiverROll;
    }

    public void setReceiverROll(int receiverROll) {
        this.receiverROll = receiverROll;
    }

    public int getSenderRoll() {
        return senderRoll;
    }

    public void setSenderRoll(int senderRoll) {
        this.senderRoll = senderRoll;
    }
}
