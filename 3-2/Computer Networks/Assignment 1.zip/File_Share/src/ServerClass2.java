/**
 * Created by sakib on 24-Sep-17.
 */
import org.omg.CORBA.*;

import java.io.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.*;

public class ServerClass2 {

    public static ServerSocket serverSocket=null;
    public static Socket socket=null;
    public  static final int socketPort=2222;

    public static final int clientMax=100; //maximum no of clients at a time
    public static final ClientThread[] THREAD_CLIENTS=new ClientThread[clientMax];

    static int bufferSize=204800;
    static int currentBufferSize=0;

    byte[] MainBuffer=new byte[bufferSize];



    public static void ConnectionFunction()
    {
        try{
            serverSocket=new ServerSocket(socketPort);

        } catch (IOException e)
        {
            System.out.println(e);
        }

        while(true)
        {
            try{
                socket=serverSocket.accept();
                DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
                DataOutputStream dataOutputStream=new DataOutputStream(socket.getOutputStream());

                dataOutputStream.writeUTF("NEW");

                //System.out.println("Connection accepted");

                //dataOutputStream.writeUTF("SENDER OR RECEIVER");

                int k=0;

                while(k<clientMax)
                {
                    if(THREAD_CLIENTS[k]==null)
                    {
                        //System.out.println("THREAD AT SERVER");
                        (THREAD_CLIENTS[k]=new ClientThread(socket, THREAD_CLIENTS, dataInputStream, dataOutputStream)).start();
                        break;
                    }

                    k++;
                }

                if(k==clientMax)
                {
                   // PrintStream os=new PrintStream(socket.getOutputStream());
                   // os.println("Server is busy. Try later!!!");
                    // os.close();
                    socket.close();
                }

            } catch (IOException e)
            {
                System.out.println(e);
            }
        }
    }


    public static void main(String args[])
    {
        System.out.println("Waiting");
        ConnectionFunction();
    }

}
