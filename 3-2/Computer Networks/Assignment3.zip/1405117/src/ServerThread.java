/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.sun.org.apache.xpath.internal.operations.Bool;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author samsung
 */
public class ServerThread implements Runnable, Serializable {
    private Thread t;
    private Socket socket;
    private ObjectInputStream input;
    private ObjectOutputStream output;
    private EndDevice device;
    public int hopCount=0;
    private ArrayList<Router> routingPath=new ArrayList<>();
    
    public ServerThread(Socket socket, EndDevice device){
        
        this.socket = socket;
        this.device=device;
        try {
            output = new ObjectOutputStream(socket.getOutputStream());
            output.flush();
            input = new ObjectInputStream(socket.getInputStream());
            
        } catch (IOException ex) {
            Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Server Ready for client "+NetworkLayerServer.clientCount);
        NetworkLayerServer.clientCount++;
        
        t=new Thread(this);
        t.start();
    }

    @Override
    public void run() {
        /**
         * Synchronize actions with client.
         */
        /*
        Tasks:
        1. Upon receiving a packet server will assign a recipient.
        [Also modify packet to add destination]
        2. call deliverPacket(packet)
        3. If the packet contains "SHOW_ROUTE" request, then fetch the required information
                and send back to client
        4. Either send acknowledgement with number of hops or send failure message back to client
        */
        try{
            output.writeObject(device);
            output.writeObject(NetworkLayerServer.clientsActive);
            while (true)
            {
                try {
                    String randomMessage=(String)input.readObject();
                    System.out.println(randomMessage);
                    IPAddress randomReceiver= (IPAddress) input.readObject();
                    System.out.println(randomReceiver);
                    String specialMessage=(String) input.readObject();
                    System.out.println(specialMessage);
                    if(specialMessage.equals("SHOW_ROUTE"))
                    {
                        Packet packet=new Packet(randomMessage,specialMessage,device.getIp(),randomReceiver);
                        Boolean deliverySuccess = deliverPacket(packet);
                        if(deliverySuccess)
                        {
                            output.writeInt(hopCount);
                            output.flush();
                            output.writeObject(routingPath);
                            output.flush();
                        }
                        else
                        {
                            output.writeInt(-1);
                            output.flush();
                            output.writeObject(routingPath);
                        }

                    }


                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }catch (IOException ex) {
            Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns true if successfully delivered
     * Returns false if packet is dropped
     * @param p
     * @return 
     */
    public Boolean deliverPacket(Packet p)
    {
        /*
        1. Find the router s which has an interface
                such that the interface and source end device have same network address.
        */
        int flag=0;
        Router s=null;
        Short[] sourceByte  =p.getSourceIP().getBytes();

        for(Router r:NetworkLayerServer.routers)
        {
            for(IPAddress ip:r.getInterfaceAddrs())
            {
                Short [] interfaceRouterBytes=ip.getBytes();
                Boolean var=true;
                for(int i=0; i<3; i++)
                {
                    if(!Objects.equals(sourceByte[i], interfaceRouterBytes[i]))
                    {
                        var=false;
                    }
                }

                if(var)
                {
                    s=r;
                    flag=1;
                    break;
                }
            }
            if(flag==1) break;
        }
        /*
        2. Find the router d which has an interface
                such that the interface and destination end device have same network address.
        */
        flag=0;
        Router d=null;
        Short[] destByte  =p.getDestinationIP().getBytes();
        for(Router r:NetworkLayerServer.routers)
        {
            for(IPAddress ip:r.getInterfaceAddrs())
            {

                Short [] interfaceRouterBytes=ip.getBytes();
                Boolean var=true;
                for(int i=0; i<3; i++)
                {
                    if(!Objects.equals(destByte[i], interfaceRouterBytes[i]))
                    {
                        var=false;
                    }
                }

                if(var)
                {
                    d=r;
                    flag=1;
                    break;
                }
            }
            if(flag==1) break;
        }
        /*
        3. Implement forwarding, i.e., s forwards to its gateway router x considering d as the destination.
                similarly, x forwards to the next gateway router y considering d as the destination, 
                and eventually the packet reaches to destination router d.
            */


        /*
            3(a) If, while forwarding, any gateway x, found from routingTable of router x is in down state[x.state==FALSE]
                    (i) Drop packet
                    (ii) Update the entry with distance Constants.INFTY
                    (iii) Block NetworkLayerServer.stateChanger.t
                    (iv) Apply DVR starting from router r.
                    (v) Resume NetworkLayerServer.stateChanger.t
        */
        if(!s.getState() || !d.getState() ) return false;
        Router sourceTemp=s;
        Router destTemp=d;
        routingPath.add(s);
        while(true)
        {
            for(int i=0; i<sourceTemp.getRoutingTable().size(); i++)
            {
                RoutingTableEntry entry=sourceTemp.getRoutingTable().get(i);
                if(entry.getRouterId()==destTemp.getRouterId())
                {
                    int gateWayId=entry.getGatewayRouterId();
                    for(Router r:NetworkLayerServer.routers)
                    {
                        if(r.getRouterId()==gateWayId)
                        {
                            for(RoutingTableEntry entry1:r.getRoutingTable())
                            {
                                if(entry1.getRouterId()==sourceTemp.getRouterId() && entry1.getDistance()==Constants.INFTY)
                                {
                                    entry1.setDistance(1);
                                    NetworkLayerServer.stateChanger.t.stop();
                                    NetworkLayerServer.DVR(r.getRouterId());
                                    NetworkLayerServer.stateChanger=new RouterStateChanger();
                                    break;
                                }
                            }
                            sourceTemp=r;
                            break;
                        }
                    }
                    break;
                }

            }
            if(!sourceTemp.getState())
            {
                for(Router r:NetworkLayerServer.routers)
                {
                    for(RoutingTableEntry entry: r.getRoutingTable())
                    {
                        if(entry.getRouterId()==sourceTemp.getRouterId())
                        {
                            entry.setDistance(Constants.INFTY);
                        }
                    }
                }
                NetworkLayerServer.stateChanger.t.stop();
                NetworkLayerServer.DVR(sourceTemp.getRouterId());
                NetworkLayerServer.stateChanger=new RouterStateChanger();
                return  false;
            }

            if(sourceTemp.getRouterId()==d.getRouterId())
            {
                routingPath.add(d);
                return true;
            }
            routingPath.add(sourceTemp);
            hopCount++;
        }

    }
        /*


                            
            3(b) If, while forwarding, a router x receives the packet from router y, 
                    but routingTableEntry shows Constants.INFTY distance from x to y,
                    (i) Update the entry with distance 1
                    (ii) Block NetworkLayerServer.stateChanger.t
                    (iii) Apply DVR starting from router x.
                    (iv) Resume NetworkLayerServer.stateChanger.t
                            
        4. If 3(a) occurs at any stage, packet will be dropped, 
            otherwise successfully sent to the destination router
        */


    @Override
    public boolean equals(Object obj) {
        return super.equals(obj); //To change body of generated methods, choose Tools | Templates.
    }

}
