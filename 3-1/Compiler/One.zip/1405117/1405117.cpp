#include <bits/stdc++.h>
using namespace std;
int m,global_id=0;
class SymbolInfo
{
    string SymbolName, SymbolType;

public:

    SymbolInfo *symbolPointer;
    SymbolInfo()
    {
        symbolPointer=NULL;
    }
    SymbolInfo(string name,string type)
    {
        SymbolName=name;
        SymbolType=type;
        symbolPointer=NULL;
    }
    void setName(string name);
    string getName();
    void setType(string type);
    string getType();
};

void SymbolInfo::setName(string name)
{
    SymbolName=name;
}
string SymbolInfo::getName()
{
    return SymbolName;
}

void SymbolInfo::setType(string type)
{
    SymbolType=type;
}

string SymbolInfo::getType()
{
    return SymbolType;
}
//ends


class ScopeTable
{
public:

    SymbolInfo *pointer_ara;
    ScopeTable *parentScope;
    int id;
    int buck_len;
    static int table_id_stat;
    ScopeTable()
    {
        pointer_ara=new SymbolInfo[m+1];
        parentScope=NULL;
        buck_len=m;
        table_id_stat++;
        id=table_id_stat-global_id;
    }
    ScopeTable(int n)
    {
        //table_id=0;
        buck_len=n;
        pointer_ara=new SymbolInfo[m+1];
        parentScope=NULL;
        table_id_stat++;
        id=table_id_stat-global_id;
    }
    ~ScopeTable()
    {
        table_id_stat--;
        delete[] pointer_ara;
        delete parentScope;
    }
    int hashFunc(string key_name);
    bool ScopeInsert(SymbolInfo *obj);
    SymbolInfo* ScopeLookUp(string key);
    bool ScopeDelete(string key);
    void ScopePrint();
};

int ScopeTable::table_id_stat=0;

int ScopeTable::hashFunc(string key_name)
{
    int total=0;
    for(int i=0; i<key_name.length(); i++)
    {
        total+=key_name[i];
    }
    int key=(total*(key_name.length())+5)%buck_len;
    //cout<<key;
    return key;
}

bool ScopeTable::ScopeInsert(SymbolInfo *obj)
{

    int key=hashFunc(obj->getName());
    SymbolInfo *temp=new SymbolInfo;
    temp=&pointer_ara[key];
    int i=0;

    while(temp->symbolPointer!=NULL)
    {

        if(temp->symbolPointer->getName()==obj->getName())
        {
            cout<<"Input already inserted in this Scope"<<endl;
            return false;
        }
        temp=temp->symbolPointer;
        i++;
    }
    //cout<<"hi"<<endl;
    temp->symbolPointer=obj;
    cout<<"Inserted in ScopeTable #"<<id<<" at position "<<key<<", "<<i<<endl;
    return true;
}

SymbolInfo* ScopeTable::ScopeLookUp(string key_name)
{
    int key=hashFunc(key_name);
    SymbolInfo *temp=new SymbolInfo;
    temp=&pointer_ara[key];
    int i=0;
    while(temp!=NULL)
    {
        if(temp->getName()==key_name)
        {
            cout<<"Found in ScopeTable #"<<id<<" at position "<<key<<", "<<i-1<<endl;
            return temp;
        }
        temp=temp->symbolPointer;
        i++;
    }
    //cout<<"Not Found"<<endl;
    return temp;
}

bool ScopeTable::ScopeDelete(string key_name)
{
    int key=hashFunc(key_name);
    SymbolInfo *temp=new SymbolInfo;
    temp=&pointer_ara[key];
    int i=0;
    while(temp->symbolPointer!=NULL)
    {
        if(temp->symbolPointer->getName()==key_name)
        {
            temp->symbolPointer=temp->symbolPointer->symbolPointer;
            cout<<"Deleted entry at "<< key<<", "<<i<<" from current ScopeTable"<<endl;
            //delete temp_2;
            return true;
        }
        i++;
        temp=temp->symbolPointer;
    }
    if(temp->getName()==key_name)
    {

    }
    cout<<key_name<<" not Found"<<endl;
    return false;
}

void ScopeTable::ScopePrint()
{
    for(int i=0; i<m; i++)
    {
        SymbolInfo *temp3=new SymbolInfo;
        temp3=pointer_ara[i].symbolPointer;
        //cout<<temp;
        cout<<i<<"---> ";
        while(temp3!=NULL)
        {
           //cout<<temp->SymbolName;
           //string s1=temp->getName();
           //cout <<" < "<<temp3->SymbolName<<" : "<<temp3->SymbolType<<" >  ";
            cout <<" < "<<temp3->getName()<<" : "<<temp3->getType()<<" >  ";
            temp3=temp3->symbolPointer;
        }
        cout<<endl;
    }
}

class SymbolTable
{
    ScopeTable *current_table;
public:
    int rem_buk;
    SymbolTable()
    {
        current_table=new ScopeTable;
        current_table->buck_len=m;
        rem_buk=m;
    }
    SymbolTable(int n)
    {
        current_table=new ScopeTable;
        current_table->buck_len=n;
        rem_buk=n;
    }
    void EnterScope();
    void ExitScope();
    bool Insert(SymbolInfo *obj);
    bool Remove(string key_name);
    bool LookUp(string s);
    void printCurrent();
    void printAll();
};

void SymbolTable::EnterScope()
{
    ScopeTable *temp=new ScopeTable(m);
    temp->buck_len=rem_buk;
    temp->parentScope=current_table;
    //cout<<temp->parentScope<<endl;
    current_table=temp;
    //cout<<current_table<<"cur"<<endl;
    cout<<"New ScopeTable with id "<< current_table->id <<" created"<<endl;
    //global_id++;
}

void SymbolTable::ExitScope()
{
    cout<<"ScopeTable with id "<<current_table->id<<" removed"<<endl;
    if(current_table->parentScope!=NULL)
    {
         current_table=current_table->parentScope;
         global_id++;
    }

}

bool SymbolTable::Insert(SymbolInfo *obj)
{
    //cout<<current_table<<endl;
    bool res=current_table->ScopeInsert(obj);
    return res;
}
bool SymbolTable::Remove(string key_name)
{
    bool h=current_table->ScopeLookUp(key_name);
    bool res=current_table->ScopeDelete(key_name);
    return res;

}
bool SymbolTable::LookUp(string key_name)
{
    SymbolInfo *temp=new SymbolInfo;
    temp=current_table->ScopeLookUp(key_name);
    ScopeTable *temp_scope=new ScopeTable;
    temp_scope=current_table;
    while(temp==NULL && temp_scope->parentScope!=NULL)
    {
        temp_scope=temp_scope->parentScope;
        temp=temp_scope->ScopeLookUp(key_name);
    }
    if(temp==NULL)
    {
        cout<<"Not Found"<<endl;
        return false;
    }
    return true;
}

void SymbolTable::printCurrent()
{
    current_table->ScopePrint();
}

void SymbolTable::printAll()
{
    ScopeTable *temp2=new ScopeTable;
    temp2=current_table;
    while(temp2->parentScope!=NULL)
    {
        cout<<"----ScopeID #"<<temp2->id<<"----------"<<endl;
        temp2->ScopePrint();
        cout<<endl;
        temp2=temp2->parentScope;
    }
    cout<<"----ScopeID #"<<temp2->id<<"----------"<<endl;
    temp2->ScopePrint();
}
int main()
{
    int buck_len;
    cin>>buck_len;
    m=buck_len;
    SymbolTable obj_symbol(buck_len);
    //obj_symbol.EnterScope();
    while(1)
    {

        char ch;
        cin>>ch;
        if(ch=='I')
        {
            string key_name, type;
            cin>>key_name;
            cin>>type;
            SymbolInfo *temp=new SymbolInfo ;
            temp->setName(key_name);
            temp->setType(type);
            bool h=obj_symbol.Insert(temp);
        }
        else if(ch=='L')
        {
            string key_name;
            cin>>key_name;
            bool h=obj_symbol.LookUp(key_name);
        }
        else if(ch=='D')
        {
            string key_name;
            cin>>key_name;
            bool h=obj_symbol.Remove(key_name);
        }
        else if(ch=='P')
        {
            char a;
            cin>>a;
            if(a=='A')
            {
                obj_symbol.printAll();
            }
            else if(a=='C')
            {
                obj_symbol.printCurrent();
            }
        }

        else if(ch=='S')
        {
            obj_symbol.EnterScope();
        }
        else if(ch=='E')
        {
            obj_symbol.ExitScope();
        }

    }
    return 0;
}
