#ifndef SymbolTable_h
#define SymbolTable_h
#include <bits/stdc++.h>
#include <fstream>  
using namespace std;
#define INFINIT 10000000


class SymbolInfo
{
public:

    string SymbolName, SymbolType;
    int valInt;
    float valFloat;
    int index;
    int arrInt[110];
    float arrFloat[110];
    int typeVal;
    int sizArr;

    SymbolInfo *symbolPointer;
    SymbolInfo()
    {
        symbolPointer=NULL;
        SymbolName="";
        SymbolType="";

        typeVal=-1;
        sizArr=1;
        index=-1;
        valInt = INFINIT;
        valFloat = INFINIT;
	//ofstream logout3("log.txt", ofstream::app);
	//logout3<<"symbol1"<<endl;
	
    }
    SymbolInfo(string name,string type)
    {
        SymbolName=name;
        SymbolType=type;
        symbolPointer=NULL;

        typeVal=-1;
        sizArr=1;
        index=-1;
        valInt = INFINIT;
        valFloat = INFINIT;
	//ofstream logout3("log.txt");
	//logout3<<"symbol2"<<endl;
	
    }

    SymbolInfo(string SymbolName, string SymbolType, int typeVal, int sizArr, int index, int valInt, float valFloat)
    {	
	symbolPointer=NULL;
	//ofstream logout3("log.txt", ofstream::app);
	//logout3<<"symbol3"<<endl;
        this->SymbolName=SymbolName;
        this->SymbolType=SymbolType;

        this->typeVal=typeVal;
        this->sizArr=sizArr;
        this->index=index;
        if(typeVal==0)
        {
            this->valInt=valInt;
            this->valFloat=INFINIT;
        }
        else if(typeVal==1)
        {
            this->valInt=INFINIT;
            this->valFloat=valFloat;
        }

        else if(typeVal==3)
        {
            for(int i=0; i<sizArr; i++)
            {
                this->arrInt[i]=INFINIT;
            }
        }
        else if(typeVal==4)
        {
            for(int i=0; i<sizArr; i++)
            {
                this->arrFloat[i]=INFINIT;
            }
        }
    }

};

/*
    Scopeclass;
*/

class ScopeTable
{
public:
    
    SymbolInfo *pointer_ara;
    ScopeTable *parentScope;
    int id;
    int buck_len;
    int table_id_stat;

    ScopeTable()
    {
        pointer_ara=new SymbolInfo[8];
        parentScope=NULL;
        buck_len=7;
        table_id_stat=1;
        id=table_id_stat++;
	//ofstream logout3("log.txt", ofstream::app);
	//logout3<<"scope1"<<endl;
    }
    ScopeTable(int m)
    {
        //table_id=0;
        buck_len=7;
        pointer_ara=new SymbolInfo[7+1];
        parentScope=NULL;
        table_id_stat=1;
        id=table_id_stat++;
	//ofstream logout3("log.txt", ofstream::app);
	//logout3<<"scope2"<<endl;
    }
    /*~ScopeTable()
    {
        //table_id_stat--;
        delete[] pointer_ara;
        delete parentScope;
    }*/
	
    int hashFunc(string key_name)
    {
	//ofstream logout3("log.txt", ofstream::app);
	//logout3<<"hash"<<endl;
    	int total=0;
    	for(int i=0; i<key_name.length(); i++)
   	 {
       		 total+=key_name[i];
    	}
    	int key=(total*(key_name.length())+5)%buck_len;
    	//cout<<key;
    	return key;
     }

   bool ScopeInsert(string SymbolName, string SymbolType, int typeVal, int sizArr, int index, int valInt, float valFloat)
    {
	// ofstream logout3("log.txt");
	ofstream logout3("log.txt", ofstream::app);
	//logout3<<"InsertedScope"<<endl;

   	 int key=hashFunc(SymbolName);
   	 SymbolInfo *temp=new SymbolInfo;
   	 temp=&pointer_ara[key];
   	 int i=0;

   	 while(temp->symbolPointer!=NULL)
   	 {
	
   	     if(temp->symbolPointer->SymbolName==SymbolName)
   	     {
   	         if(typeVal==0)
   	         {
   	             temp->symbolPointer->valInt=valInt;
   	         }
   	         else if(typeVal==1)
   	         {
   	             temp->symbolPointer->valFloat=valFloat;
   	         }
   	         else if(typeVal==2)
   	         {
   	             temp->symbolPointer->arrInt[index]=valInt;
   	         }
   	         else if(typeVal==3)
   	         {
   	             temp->symbolPointer->arrFloat[index]=valFloat;
   	         }
   	         logout3<<"Input already inserted in this Scope"<<endl;
   	         return false;
   	     }
   	     temp=temp->symbolPointer;
   	     i++;
   	 }
   	 //cout<<"hi"<<endl;
   	 SymbolInfo *obj=new SymbolInfo(SymbolName,  SymbolType, typeVal, sizArr, index,  valInt,  valFloat);
   	 temp->symbolPointer=obj;
   	 logout3<<"Inserted in ScopeTable #"<<id<<" at position "<<key<<", "<<i<<endl;
    	return true;
    }
    SymbolInfo* ScopeLookUp(string key_name)
    {
	ofstream logout3("log.txt", ofstream::app);
    	int key=hashFunc(key_name);
    	SymbolInfo *temp=new SymbolInfo();
    	temp=&pointer_ara[key];
    	int i=0;
    	while(temp!=NULL)
    	{
       		 if(temp->SymbolName==key_name)
        	{
           		 logout3<<"Found in ScopeTable #"<<id<<" at position "<<key<<", "<<i-1<<endl;
           		 return temp;
        	}
        	temp=temp->symbolPointer;
        	i++;
   	 }
    	//cout<<"Not Found"<<endl;
    	return temp;
    }
    
    void ScopePrint()
    {
	ofstream logout3("log.txt", ofstream::app);
    	for(int i=0; i<7; i++)
    	{
        	SymbolInfo *temp3=new SymbolInfo;
        	temp3=pointer_ara[i].symbolPointer;
        	//cout<<temp;
        	logout3<<i<<"---> ";
        	while(temp3!=NULL)
        	{
           		//cout<<temp->SymbolName;
           		//string s1=temp->getName();
           		//cout <<" < "<<temp3->SymbolName<<" : "<<temp3->SymbolType<<" >  ";
            		logout3 <<" < "<<temp3->SymbolName <<", " <<temp3->SymbolType<<", ";
            
           	 if(temp3->typeVal==0)
           	 {
               		 logout3<<temp3->valInt<<" ";
                	//cout<<"A"<<endl;
            	}
            	else if(temp3->typeVal==1)
            	{
                	logout3<<temp3->valFloat<<" ";
                	//cout<<"B"<<endl;
            	}
            	else if(temp3->typeVal==2)
            	{
                	logout3<<"{ ";
                	int j;
                	for(j=0; j<temp3->sizArr; j++)
                	{
                   		 logout3<<temp3->arrInt[j]<<", ";
                	}
               		 logout3<<temp3->arrInt[j]<<" }";
               		// cout<<"C"<<endl;

            	}
            	else if(temp3->typeVal==3)
            	{
               		 logout3<<"{";
                	int j;
                	for( j=0;j<temp3->sizArr;j++)
                	{
                   		 logout3<<temp3->arrFloat[j]<<", ";
               		 }
               		 logout3<<temp3->arrFloat[j]<<" }";
               		 //cout<<"D"<<endl;
            	}

            	logout3<<" > ";
            	//cout<<"E"<<endl;

            	temp3=temp3->symbolPointer;
           	 //cout<<"F"<<endl;
        	}
        	//cout<<"G"<<endl;
        	logout3<<endl;
    	}
    	//cout<<"H"<<endl;
    }

};









class SymbolTable
{
    ScopeTable *current_table;
public:
    int rem_buk;
    

  
    SymbolTable(int n)
    {
        current_table=new ScopeTable(n);
        current_table->buck_len=n;
        rem_buk=n;
    }
	
	
    void EnterScope()
    {	
	ofstream logout3("log.txt", ofstream::app);
	logout3<<"hi"<<endl;
    	ScopeTable *temp=new ScopeTable(7);
    	temp->buck_len=rem_buk;
    	temp->parentScope=current_table;
    	//cout<<temp->parentScope<<endl;
    	current_table=temp;
    	//cout<<current_table<<"cur"<<endl;
    	logout3<<"New ScopeTable with id "<< current_table->id <<" created"<<endl;
    	//global_id++;
    }
    void ExitScope()
    {	
	ofstream logout3("log.txt", ofstream::app);
    	logout3<<"ScopeTable with id "<<current_table->id<<" removed"<<endl;
    	if(current_table->parentScope!=NULL)
    	{
         	current_table=current_table->parentScope;
         	//global_id++;
    	}

    } 
    void Insert(string SymbolName, string SymbolType, int typeVal, int sizArr, int index, int valInt, float valFloat)
    {
    	
    	bool res=current_table->ScopeInsert(SymbolName, SymbolType,  typeVal,  sizArr,  index,  valInt,  valFloat);
	
	ofstream logout3("log.txt", ofstream::app);
	logout3<<"Inserted "<<res<<endl;
    	//return res;
    }
    
    SymbolInfo* lookup(string key_name)
    {
	ofstream logout3("log.txt", ofstream::app);
	logout3<<"Look up "<<endl;

    	SymbolInfo *temp=new SymbolInfo();
    	temp=current_table->ScopeLookUp(key_name);
    	ScopeTable *temp_scope=new ScopeTable(7);
    	temp_scope=current_table;
   	 while(temp==NULL && temp_scope->parentScope!=NULL)
    	{
        	temp_scope=temp_scope->parentScope;
        	temp=temp_scope->ScopeLookUp(key_name);
    	}
    	if(temp==NULL)
    	{
        	//cout<<"Not Found"<<endl;
        	return temp;
    	}
    	return temp;
    }

    void printCurrent()
    {
    	current_table->ScopePrint();
    }

    void printAll()
    {
	ofstream logout3("log.txt", ofstream::app);
    	ScopeTable *temp2=new ScopeTable;
    	temp2=current_table;
    	while(temp2->parentScope!=NULL)
    	{
        	logout3<<"----ScopeID #"<<temp2->id<<"----------"<<endl;
        	temp2->ScopePrint();
        	logout3<<endl;
        	temp2=temp2->parentScope;
    	}
    	logout3<<"----ScopeID #"<<temp2->id<<"----------"<<endl;
    	temp2->ScopePrint();
     }
};













#endif


