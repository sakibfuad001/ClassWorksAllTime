package sample;

import com.sun.org.apache.xpath.internal.SourceTree;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import sun.reflect.generics.tree.Tree;

import javax.swing.*;
import javax.swing.filechooser.FileSystemView;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.List;
import javafx.scene.control.Button;

import javafx.scene.input.MouseEvent;


public class Controller implements Initializable {
    @FXML //directory
    private TextArea text;
    @FXML //root
    private Pane rootpane;
    @FXML //treeView
    private TreeView tree;
    @FXML
    private TableView<FilleInfoHolder> table;
    @FXML //detailsViewColumns
    private TableColumn<FilleInfoHolder, Node> icon;
    @FXML
    private TableColumn<FilleInfoHolder, String> name;
    @FXML
    private TableColumn<FilleInfoHolder, Long> size;
    @FXML
    private TableColumn<FilleInfoHolder, String> date;
    @FXML //viewbutton
    private MenuItem list;
    @FXML
    private MenuItem details;
    @FXML
    private TilePane tilePane;
    @FXML
    private VBox vbox;
    @FXML
    private Button btn;
    @FXML
    private ScrollPane scrlPane;

    private static int var=1;
    public String fullPath;

    private final Node rootIcon = new ImageView(
            new Image(getClass().getResourceAsStream("myPc2.png"))
    );


//
//    public void handle (ActionEvent e) {
//        System.out.println("Opening Database Connection...");
//    }


    //tree.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> handle(newValue));


    /*
    **This function returns the image Icons of the files
     */
    public final ImageView fileIcon(File f){
        ImageIcon icon = (ImageIcon) FileSystemView.getFileSystemView().getSystemIcon(f);
        BufferedImage bufferedImage = new BufferedImage(icon.getIconWidth(), icon.getIconHeight(), BufferedImage.TYPE_INT_ARGB);
        icon.paintIcon(null, bufferedImage.getGraphics(), 0, 0);
        Image fxImage = SwingFXUtils.toFXImage(bufferedImage, null);
        ImageView iview = new ImageView(fxImage);
        iview.setPreserveRatio(true);
        iview.setSmooth(true);
        iview.setFitWidth(18);
        return iview;
    }


    /*
    **this fun returns the all subfolders
     */
    private TreeItem<String> getNodesForDirectory (File k) throws Exception
    {
        Node icon=fileIcon(k);
        TreeItem<String> boss=new TreeItem<String>(k.getAbsolutePath(), icon);
        int i=1;
        for(File f: k.listFiles())
        {
            //System.out.println(f.isDirectory());
            try {

                if (f.toString()!=null && f.isDirectory() == true) {
                    //ImageView iv=fileIcon(f);
                    //Node icon=fileIcon(f);
                    boss.getChildren().add(getNodesForDirectory(f));
                    //System.out.println("1");
                }else{
                    //System.out.println(f.getName());
//                    Node icon2=fileIcon(f);
//                    boss.getChildren().add(new TreeItem<String>(f.getAbsolutePath(),icon2));
                }
            }catch (Exception e)
            {
                //System.out.println(e+" blink");
            }
        }

        return boss;
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //File folder=new File("This P")
        //setup the file browser root

        String hostName="MY PC";

        //try{hostName= InetAddress.getLocalHost().getHostName();}catch(UnknownHostException x){}

        TreeItem<String> rootNode=new TreeItem<String>(hostName, rootIcon);

        Iterable<Path> rootDirectories= FileSystems.getDefault().getRootDirectories();


        for(Path k:rootDirectories)
        {
            File temp=new File(k.toString());
            System.out.println(temp.length());

            Node iconTemp=fileIcon(temp);
            TreeItem<String> temp2=new TreeItem<String>(k.toString(), iconTemp);


            for(File f:temp.listFiles())
            {
                try {
                    //System.out.println(f);
                    TreeItem<String> returnItem = getNodesForDirectory(f);
                    //System.out.println(returnItem);
                    temp2.getChildren().add(returnItem);
                }catch (Exception e)
                {
                    //System.out.println(e+" tltk");
                }
            }

            rootNode.getChildren().add(temp2);


        }


        //2nd way
//
//        File x=new File("E:\\");
//        File[] rootFolder= x.listFiles();
//
//        for(File k:rootFolder){
//            System.out.println(k.getName());
//            TreeItem<String> temp=new TreeItem<String>(k.toString());
//            rootNode.getChildren().add(temp);
//
//        }

        rootNode.setExpanded(true);

       tree.setRoot(rootNode);

        tree.setOnMouseClicked(new EventHandler<MouseEvent>()
        {
            @Override
            public void handle(MouseEvent mouseEvent)
            {
                if(mouseEvent.getClickCount() == 2)
                {
                    table.getItems().clear();
                    //StringBuilder pathBuilder=new StringBuilder();
                    TreeItem<String> item2=(TreeItem<String>) tree.getSelectionModel().getSelectedItem();
                    fullPath=item2.getValue();
                    /*
                    for(TreeItem<String> item = (TreeItem<String>) tree.getSelectionModel().getSelectedItem();
                        item!=null; item=item.getParent())
                    {
                        System.out.println("Selected Text : "+  item.getValue());
                        pathBuilder.insert(0,item.getValue());
                        pathBuilder.insert(0,"\\");
                    }*/

                    //String path=pathBuilder.toString();
                    //fullPath=path;
                    System.out.println(fullPath);
                    text.setText(fullPath);
                    text.setEditable(false);

                    /*
                    Experiment  Table View
                     */
                    TableViewFunction();
                    TilePaneFunction();


                }
            }
        });

        btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                File f=new File(fullPath);
                if(f.getParent()!=null)
                {
                    fullPath=f.getParent();

                    TilePaneFunction();
                    TableViewFunction();

                }

            }
        });

        list.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                var=2;

                tilePane.setVisible(true);
                scrlPane.setVisible(true);
                table.setVisible(false);
                TilePaneFunction();
                TableViewFunction();

            }
        });

        details.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                var=1;
                tilePane.setVisible(false);
                scrlPane.setVisible(false);
                table.setVisible(true);
                //TilePaneFunction();
                TableViewFunction();
            }
        });


    }


    public void TableViewFunction()
    {
        table.getItems().clear();
        File newTest=new File(fullPath);
        System.out.println(newTest.length());


        ObservableList<FilleInfoHolder> dataList;
        List<FilleInfoHolder> list=new ArrayList<>();
        if(newTest.isDirectory() ) {
            System.out.println("if");
            for (File j : newTest.listFiles()) {
                Node iconImage = fileIcon(j);
                Date date = new Date(j.lastModified());

                list.add(new FilleInfoHolder(iconImage, j.getName(), date.toString(), j.length(), j));
                System.out.println("Inside");
            }
        }else {
            Node iconImage = fileIcon(newTest);
            Date date = new Date(newTest.lastModified());

            list.add(new FilleInfoHolder(iconImage, newTest.getName(), date.toString(), newTest.length(), newTest));
            System.out.println("Inside");
        }
        System.out.println("bl");
        dataList=FXCollections.observableArrayList(list);
        icon.setCellValueFactory(
                new PropertyValueFactory<FilleInfoHolder, Node>("iconImage"));
        name.setCellValueFactory(
                new PropertyValueFactory<FilleInfoHolder, String>("nameString"));
        date.setCellValueFactory(
                new PropertyValueFactory<FilleInfoHolder, String>("dateString"));
        size.setCellValueFactory(
                new PropertyValueFactory<FilleInfoHolder, Long>("sizeString"));

        table.getItems().addAll(list);

        table.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if(event.getClickCount()==2)
                {
                    FilleInfoHolder obj=table.getSelectionModel().getSelectedItem();
                    if(obj.getTempFile().isDirectory()==true)
                    {
                        fullPath=obj.getTempFile().getAbsolutePath();
                    }

                    text.setText(fullPath);
                    File tempFile=obj.getTempFile();
                    TableViewFunction();

                    //System.out.println(fullPath);
                    //System.out.println(fullPath2);


                }
            }
        });

    }

    public void TilePaneFunction()
    {
        tilePane.getChildren().clear();
        tilePane.setVgap(5);
        tilePane.setHgap(10);
        File f=new File(fullPath);
        //System.out.println(f.listFiles());
        if(f.isDirectory())
        {
            for(File j:f.listFiles())
            {

                MBox mBox;
                Node icon=fileIcon(j);
                Label temp=new Label(j.getName());
                mBox=new MBox(j,icon,temp);
                mBox.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent event) {
                        File temp= mBox.getF();
                        if(event.getClickCount()==2)
                        {
                            if(temp.isDirectory()==true)
                            {
                                fullPath=temp.getAbsolutePath();
                            }

                            TilePaneFunction();
                        }
                    }
                });
                tilePane.getChildren().addAll(mBox);
            }
        }
        else
        {

        }

        //vbox.getChildren().addAll(tilePane);
    }





}
