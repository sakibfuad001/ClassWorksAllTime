package sample;

import javafx.scene.Node;
import javafx.scene.layout.VBox;

import java.io.File;

/**
 * Created by sakib on 27-Apr-17.
 */
public class MBox extends VBox {
    public File f;

    public MBox(File f) {
        this.f = f;
    }

    public MBox(double spacing, File f) {
        super(spacing);
        this.f = f;
    }

    public MBox(File f, Node... children) {
        super(children);
        this.f = f;
    }

    public MBox(double spacing, File f, Node... children) {
        super(spacing, children);
        this.f = f;
    }

    public File getF() {
        return f;
    }

    public void setF(File f) {
        this.f = f;
    }
}
