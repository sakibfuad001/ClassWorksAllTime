package sample;

import javafx.scene.Node;

import java.io.File;
import java.text.DecimalFormat;

/**
 * Created by sakib on 24-Apr-17.
 */
public class FilleInfoHolder {
    private Node iconImage;
    private String nameString;
    private String dateString;
    private String sizeString;
    private File tempFile;

    public FilleInfoHolder(Node iconImage, String nameString, String dateString, Long sizeString,File tempFile) {
        this.iconImage = iconImage;
        this.nameString = nameString;
        this.dateString = dateString;
        this.sizeString = bytesToHuman(sizeString);
        this.tempFile=tempFile;

    }

    public Node getIconImage() {
        return iconImage;
    }

    public void setIconImage(Node iconImage) {
        this.iconImage = iconImage;
    }

    public String getNameString() {
        return nameString;
    }

    public void setNameString(String nameString) {
        this.nameString = nameString;
    }

    public String getDateString() {
        return dateString;
    }

    public void setDateString(String dateString) {
        this.dateString = dateString;
    }

    public String getSizeString() {
        return sizeString;
    }

    public void setSizeString(String sizeString) {
        this.sizeString = sizeString;
    }

    public static String floatForm (double d)
    {
        return new DecimalFormat("#.##").format(d);
    }

    public File getTempFile() {
        return tempFile;
    }

    public void setTempFile(File tempFile) {
        this.tempFile = tempFile;
    }

    public static String bytesToHuman (long size)
    {
        long Kb = 1  * 1024;
        long Mb = Kb * 1024;
        long Gb = Mb * 1024;
        long Tb = Gb * 1024;
        long Pb = Tb * 1024;
        long Eb = Pb * 1024;

        if (size <  Kb)                 return floatForm(        size     ) + " byte";
        if (size >= Kb && size < Mb)    return floatForm((double)size / Kb) + " Kb";
        if (size >= Mb && size < Gb)    return floatForm((double)size / Mb) + " Mb";
        if (size >= Gb && size < Tb)    return floatForm((double)size / Gb) + " Gb";
        if (size >= Tb && size < Pb)    return floatForm((double)size / Tb) + " Tb";
        if (size >= Pb && size < Eb)    return floatForm((double)size / Pb) + " Pb";
        if (size >= Eb)                 return floatForm((double)size / Eb) + " Eb";

        return "???";
    }

}
