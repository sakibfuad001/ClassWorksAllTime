#include<bits/stdc++.h>
using namespace std;
#define INF 1000000000

map < string , map < string, int> > edge;
map< string,  vector <string > > aa;
map< string, int> dd;
string first_name;

int main()
{
    int G;
    cin>>G;
    for(int s=1; s<=G; s++)
    {
        edge.clear();
        aa.clear();
        dd.clear();
        int t;
        cin>>t;
        string name, str2;
        for(int i=0; i<t; i++)
        {
            int n,a,sum=0;
            cin>>name>>n;
            if(i==0)
            {
                first_name=name;
            }
            dd[name]=INF;
            for(int j=0; j<n; j++)
            {
                cin>>str2>>a;
                sum=sum+a;
                edge[name][str2]=sum;
                edge[str2][name]=sum;
                //cout<<edge[name][str2]<<" "<<edge[str2][name]<<endl;;
                aa[name].push_back(str2);
                aa[str2].push_back(name);
            }
        }



        priority_queue < pair < int, string > > qq;
        qq.push(make_pair(0, first_name));
        dd[first_name]=0;

        while(!qq.empty())
        {
            pair < int , string > pp=qq.top();
            string str=pp.second;
            int u=pp.first;
            if(u<0)u=-u;
            qq.pop();
            int length=aa[str].size();
           // cout<<"len:"<<length<< " "<<endl;

            for(int i=0; i<length; i++)
            {
                string temp;
                temp=aa[str][i];
                //cout<<"name: " <<str <<" adj"<<temp<<endl;
                int dis=u+edge[str][temp];
                if(dis<dd[temp])
                {
                    //cout<<temp<<" : "<<dis<<endl;
                    dd[temp]=dis;
                    qq.push(make_pair(-dis,temp));
                }

            }
        }
        map<string , int> :: iterator it;
        int mx=-1;
        for(it=dd.begin(); it!=dd.end(); it++)
        {
            if(mx<it->second)
            {
                mx=it->second;
            }
        }

        if(mx==INF)
        {
            cout<<"News not shared over the whole group"<<endl;
        }

        else
        {
            cout<<mx<<endl;
        }

    }
    return 0;
}
