#include<bits/stdc++.h>
using namespace std;

struct node
{
    int index;
    double value;
};

class MergeObject
{
public:
    vector<node> vv;

    MergeObject(){}
    MergeObject(vector<node> &vec)
    {
        vv=vec;
    }
    void Circulate(int i, int j);
    void Merge(int low_ind,int  mid, int  high_ind);
    void MergeSort(int low_ind, int high_ind);

};

void MergeObject::Circulate(int i,int j)
{
    int k=j;
    while(k>i)
    {
        vv[k]=vv[k-1];
        k--;
    }
}

void MergeObject:: Merge(int low_ind,int  mid, int  high_ind)
{
    int i=low_ind;
    int m=low_ind;
    int j=mid+1;

    if(vv[mid].value<=vv[mid+1].value) return;
    while(i<=mid && j<=high_ind)
    {
        if(vv[i].value<vv[j].value) i++;
        else
        {
           node temp=vv[j];
           Circulate(i,j);
           vv[i]=temp;
           i++;
           j++;
        }
    }
    if(vv[mid].value>vv[mid+1].value)
    {
        node temp=vv[mid];
        vv[mid]=vv[mid+1];
        vv[mid+1]=temp;
    }
}

void MergeObject::MergeSort( int low_ind, int high_ind)
{
    int mid;
    if(low_ind<high_ind)
    {
        mid=(low_ind+high_ind)/2;
        MergeSort(low_ind, mid);
       // cout<<"1"<<endl;
        MergeSort(mid+1, high_ind);
        Merge(low_ind, mid, high_ind);
       // cout<<"2"<<endl;
    }
    return;
}

int main()
{
    int t;
    cin>>t;

    for(int cs=1; cs<=t; cs++)
    {
        int N;
        cin>>N;

        vector<node> vv(N+2);

        for(int i=1; i<=N; i++)
        {
            double a;
            cin>>a;

            vv[i].index=i-1;
            vv[i].value=a;
        }

        MergeObject ob(vv);
        ob.MergeSort(1,N);

        cout<<"Case "<<cs<<"#"<<endl;

        for(int i=1; i<=N; i++)
        {
            cout<<ob.vv[i].value<<" ";
        }
        cout<<endl;

        for(int i=1; i<=N; i++)
        {
            cout<<ob.vv[i].index<<" ";
        }
        cout<<endl;
    }
}









