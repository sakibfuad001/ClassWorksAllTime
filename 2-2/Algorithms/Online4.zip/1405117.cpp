#include<bits/stdc++.h>
using namespace std;
struct edge{
    int a, b, w;
};

bool compare(edge ob1, edge ob2)
{
    return ob1.w<ob2.w;
}

edge vv[10000];
vector<int> p(10000);
map< int, map <int, int > > mm;
int n, m, sum, cnt;

int Find(int a)
{
    if(p[a]==a) return a;
    return p[a]=Find(p[a]);
}

int main()
{
    int t;
    cin>>t;

    for(int cs=1; cs<=t; cs++)
    {
        sum=0;
        cnt=0;
        mm.clear();
        p.clear();
        cin>>n>>m;
        for(int i=1; i<=n; i++)
        {
            p[i]=i;
        }
        for(int i=0; i<m; i++)
        {
            int a,b,w;
            cin>>a>>b>>w;
            vv[i].a=a;
            vv[i].b=b;
            vv[i].w=w;
            mm[a][b]=w;
        }
        int q;
        cin>>q;
        for(int i=0; i<q; i++)
        {
            int x,y;
            cin>>x>>y;
            int u=Find(x);
            int v=Find(y);
            if(u!=v)
            {
                sum=sum+mm[x][y];
                cnt++;
                p[x]=y;
            }

        }

        sort(vv, vv+m, compare);

        for(int i=0;i<m; i++)
        {
            int u=Find(vv[i].a);
            int v=Find(vv[i].b);
            if(u!=v)
            {
                p[u]=v;
                cnt++;
                sum=sum+vv[i].w;
                if(cnt==n-1) break;
            }
        }

        cout<<sum<<endl;

    }

    return 0;
}
