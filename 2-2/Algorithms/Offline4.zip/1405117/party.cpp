#include <bits/stdc++.h>
using namespace std;
int N;
int rat[6009];
vector <int > vv[6009];

bool visited[6009];
int dp[6009];
bool root[6009];
int root_tree;

int party_max(int rot)
{
    if(visited[rot]==true) return dp[rot];
    int sum1=0;
    sum1=sum1+rat[rot];
    int sz=vv[rot].size();

    for(int i=0; i<sz; i++)
    {
        int temp=vv[rot][i];
        int sz_temp=vv[temp].size();
        for(int j=0; j<sz_temp; j++)
        {
            sum1=sum1+party_max(vv[temp][j]);

        }
    }
    int sum2=0;
    for(int i=0; i<sz; i++)
    {
        sum2=sum2+party_max(vv[rot][i]);
    }

    visited[rot]=true;
    //cout<<"s1:"<<sum1<<" s2:"<<sum2<<endl;
    return dp[rot]=max(sum1, sum2);
}

int main()
{
    cin>>N;
    memset(root, false , sizeof root);
    memset(visited, false, sizeof visited);
    for(int i=1; i<=N; i++)
    {
        cin>>rat[i];
    }
    for(int i=0; ; i++)
    {
        int l, k;
        cin>>l>>k;
        if(l==0 && k==0) break;
        vv[k].push_back(l);
        root[l]=true;
    }

    for(int i=1; i<=N; i++)
    {
        if(root[i]==false)
        {
            root_tree=i;
            break;
        }
    }

    //cout<<"root"<<root_tree<<endl;
    int result=party_max(root_tree);
    cout<<result<<endl;

    return 0;
}
