#include <bits/stdc++.h>
using namespace std;

string str[110][110];
int dp[110][110];
string A, B;

void func(int lenA, int lenB)
{
    for(int i=0; i<=lenA; i++)
    {
        dp[lenA][0]=0;
        str[lenA][0]="";
    }
    for(int i=0; i<=lenB; i++)
    {
        dp[0][lenB]=0;
        str[0][lenB]="";
    }

    for(int i=1; i<=lenA; i++)
    {
        for(int j=1; j<=lenB; j++)
        {
            if(A[i-1]==B[j-1])
            {
                dp[i][j]=1+dp[i-1][j-1];
                str[i][j]=A[i-1]+str[i-1][j-1];

            }
            else
            {
                if(dp[i-1][j]>dp[i][j-1])
                {
                    dp[i][j]=dp[i-1][j];
                    str[i][j]=str[i-1][j];
                }
                else if(dp[i][j-1]>dp[i-1][j])
                {
                    dp[i][j]=dp[i][j-1];
                    str[i][j]=str[i][j-1];
                }
                else
                {
                    dp[i][j]=dp[i][j-1];
                    str[i][j]=min(str[i][j-1], str[i-1][j]);
                }
            }

        }
    }
}

int main()
{
    int t;
    cin>>t;

    for(int cs=1; cs<=t; cs++)
    {
        //memset(dp, -1, sizeof dp);
        cin>>A>>B;
        int lenA=A.length();
        int lenB=B.length();
        func(lenA, lenB);

        if(dp[lenA][lenB]==0)
        {
            cout<<"Case "<<cs<<": :("<<endl;
        }

        else
        {
            string ans, ans2;
            int len=dp[lenA][lenB];
            ans=str[lenA][lenB];
            for(int i=len-1; i>=0; i--)
            {
                ans2=ans2+ans[i];
            }
            cout<<"Case "<<cs<<": "<<ans2<<endl;
        }

    }

    return 0;
}
