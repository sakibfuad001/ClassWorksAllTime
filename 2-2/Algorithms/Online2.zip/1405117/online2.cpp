#include<bits/stdc++.h>
using namespace std;
int ara[10000];


int maximum (int strt, int endt)
{
    int mini=ara[strt];
    int index;
    for(int i=strt; i<=endt; i++)
    {
        if(mini>=ara[i])
        {
            mini=ara[i];
            index=i;
        }
    }
    //cout<<"m: "<<mini <<"  " <<index;
    int left=-1;
    if(index>strt)
    {
        left=maximum(strt, index-1);
    }
    int right=-1;
    if(index<endt)
    {
        right=maximum(index+1,endt);
    }
    int a = max(max(left,right),mini);
    //cout<<a<<" ";
    return a;
}

int main()
{
    int T;
    cin>>T;

    for(int cs=1; cs<=T; cs++)
    {
        int n;
        cin>>n;

        for(int i=0; i<n; i++)
        {
            cin>>ara[i];
        }

        cout<<"Case  "<<cs<<"#"<<endl;
        cout<<maximum(0,n-1);
    }
}
