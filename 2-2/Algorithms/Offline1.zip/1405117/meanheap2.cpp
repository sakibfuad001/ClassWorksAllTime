#include<bits/stdc++.h>
using namespace std;

vector<int>vv;

class Time
{
public:
    int index;
    int sT;
    int eT;
    int strt;
    int keyTime;
    string str1;
    string str2;

    Time(){}

    Time(int ind, int aa, string s1, int bb, string s2)
    {
        index=ind;
        sT=aa;
        str1=s1;
        eT=bb;
        str2=s2;

        if(s1=="A.M.")
        {
            if(aa==12)
            {
                strt=0;
            }
            else strt=aa;
        }
        else if(s1=="P.M.")
        {
            if(aa==12)
            {
                strt=12;
            }
            else
            {
                strt=12+aa;
            }
        }

        if(s2=="A.M.")
        {
            if(bb==12)
            {
                keyTime=0;
            }
            else
            {
                keyTime=bb;
            }
        }
        else if(s2=="P.M.")
        {
            if(bb==12)
            {
                keyTime=12;
            }
            else
            {
                keyTime=12+bb;
            }
        }
    }
};

Time ara[10000], temp_ara[10000], temp_ara2[10000];

class Minheap
{
public:
    int heapSize;

    void MinHeapify(int index)
    {
        int  left_child, right_child, minimum;//indexes
        Time temp;//object
        left_child=(2*index)+1;
        right_child=(2*index)+2;

        if(left_child<heapSize && ara[index].keyTime>ara[left_child].keyTime)
        {
            minimum=left_child;
        }
        else
        {
            minimum=index;
        }

        if(right_child<heapSize && ara[minimum].keyTime>ara[right_child].keyTime)
        {
            minimum=right_child;
        }

        if(minimum!=index)
        {
            temp=ara[index];
            ara[index]=ara[minimum];
            ara[minimum]=temp;
            MinHeapify(minimum);
        }

        return;
    }

    Time ExtractMin()
    {
        Time m_n;
        if(heapSize<1)
        {
            cout<<"Underflow"<<endl;
        }
        else
        {
            m_n=ara[0];
            ara[0]=ara[heapSize-1];
            heapSize=heapSize-1;
            BuildHeap();
        }
        return m_n;
    }
    void Insert(Time ob)
    {
        ara[heapSize]=ob;
        heapSize++;
        BuildHeap();
    }

    void BuildHeap()
    {
        for(int i=heapSize/2; i>=0; i--)
        {
            MinHeapify(i);
        }
    }
};

int main()
{
    int tst, a, b, n;
    string str_1,str_2;

    cin>>tst;

    for(int cs=1; cs<=tst; cs++)
    {
        cin>>n;
        Minheap qq;
        for(int i=0; i<n; i++)
        {
            cin>>a>>str_1>>b>>str_2;
            Time temp(i+1, a,str_1,b,str_2);
            temp_ara[i]=temp;
            temp_ara2[i]=temp;
        }
        int mx=-1;
        for(int i=0; i<n; i++)
        {

            qq.heapSize=0;
            temp_ara2[i]=temp_ara[i];
            for(int j=i-1; j>=0; j--)
            {
                if(temp_ara[i].keyTime<=temp_ara[j].keyTime)
                {
                    temp_ara2[j].keyTime=temp_ara[j].keyTime-temp_ara[i].keyTime;
                }
                else
                {
                    temp_ara2[j].keyTime=temp_ara[j].keyTime+24-temp_ara[i].keyTime;
                }
            }
            for(int j=i+1; j<n; j++)
            {
                if(temp_ara[i].keyTime<=temp_ara[j].keyTime)
                {
                    temp_ara2[j].keyTime=temp_ara[j].keyTime-temp_ara[i].keyTime;
                }
                else
                {
                    temp_ara2[j].keyTime=temp_ara[j].keyTime+24-temp_ara[i].keyTime;
                }
            }

            for(int j=0; j<n; j++)
            {
                qq.Insert(temp_ara2[j]);
            }
           /* for(int i=0; i<qq.heapSize; i++)
            {
                cout<<ara[i].strt<<" "<<ara[i].keyTime<<",";
            }*/
            vector<int>temp_vv;
            Time ob;
            ob=qq.ExtractMin();
            temp_vv.push_back(ob.index);
            int cnt=1;

            while(qq.heapSize>0)
            {
                Time ob2=qq.ExtractMin();

                if(ob.strt<ob.keyTime)
                {
                    if(ob.keyTime<ob2.strt)
                    {
                        if(ob.keyTime<ob2.keyTime)
                        {
                            cnt++;
                            ob=ob2;
                            temp_vv.push_back(ob.index);
                        }
                        else if(ob.strt>ob2.keyTime)
                        {
                            cnt++;
                            ob=ob2;
                            temp_vv.push_back(ob.index);
                        }
                    }
                    else if(ob.strt>ob2.keyTime)
                    {
                        if(ob.strt>ob2.strt)
                        {
                            cnt++;
                            ob=ob2;
                            temp_vv.push_back(ob.index);
                        }
                    }
                }
                else
                {
                    if(ob2.strt<ob2.keyTime && ob.keyTime<ob2.strt && ob.strt>ob2.keyTime )
                    {
                        cnt++;
                        ob=ob2;
                        temp_vv.push_back(ob.index);
                    }
                }
            }
            if(mx<cnt)
            {
                mx=cnt;
                vv.clear();
                for(vector<int >::iterator it=temp_vv.begin(); it!=temp_vv.end(); it++ )
                {
                    vv.push_back(*it);
                }
            }
        }
        cout<<mx<<endl;
        for(vector<int>::iterator it=vv.begin(); it!=vv.end(); it++)
        {
            cout<<*it<<" ";
        }
        cout<<endl;

        for(vector<int>::iterator it=vv.begin(); it!=vv.end(); it++)
        {
            cout<<temp_ara[*it-1].sT<<temp_ara[*it-1].str1<<" "<<temp_ara[*it-1].eT<<temp_ara[*it-1].str2;
        }
    }
}

/*
1
4
6 P.M. 6 A.M.
9 P.M. 4 A.M.
3 A.M. 2 P.M.
1 P.M. 7 P.M.

*/

