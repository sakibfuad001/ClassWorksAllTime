#include<stdio.h>
#include<conio.h>

int SquareFib(int n);

int main()
{
    int n;
    scanf("%d", &n);

    printf("%d", SquareFib(n));

    getch();

    return 0;
}

int SquareFib(int n)
{
    if(n==1) return 1;
    if(n==2) return 1;
    if(n==3) return 4;

    else return 2*SquareFib(n-1)+2*SquareFib(n-2)-SquareFib(n-3);
}
