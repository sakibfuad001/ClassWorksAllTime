#include <stdio.h>
#include <conio.h>

int bacteriaCount(int n);

int main()
{
    int n;
    scanf("%d", &n);
    printf("%d", bacteriaCount(n));

    getch();
    return 0;
}

int bacteriaCount(int n)
{
    if(n==0) return 0;
    if(n==1) return 1;
    if(n==2) return 1;

    else return bacteriaCount(n-1)+bacteriaCount(n-2)+bacteriaCount(n-3);
}
