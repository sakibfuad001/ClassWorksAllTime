#include <stdio.h>
#include <conio.h>

void swap(char *a, char *b);
void permutation(char *str, int begin, int end);

int main()
{
    char str[26];
    int n, i;
    scanf("%d", &n);

    for(i=0; i<n; i++){
        str[i]='a'+i;
    }
    str[n]='\0';

    permutation(str, 0, n-1);

    getch();

    return 0;
}

void swap(char *a, char *b)
{
    char c;
     c=*a;
    *a=*b;
    *b=c;
}

void permutation(char *str,int begin, int end)
{
    int j;
    if(begin==end){
        printf("%s\n", str);
    }
    else{
       for(j=begin; j<=end; j++){
        swap((str+begin), (str+j));
        permutation(str, begin+1, end);
        swap((str+begin), (str+j));

       }
    }
}



